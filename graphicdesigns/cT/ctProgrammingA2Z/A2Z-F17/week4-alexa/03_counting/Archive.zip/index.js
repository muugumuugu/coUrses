var a2z = require('./a2z');

exports.handler = a2z.lambda();
