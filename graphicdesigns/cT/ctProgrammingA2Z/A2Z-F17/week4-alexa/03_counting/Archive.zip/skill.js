var a2z = require('./a2z');

console.log("SCHEMA: ");
console.log(a2z.schema());

console.log();
console.log("UTTERANCES: ");
console.log(a2z.utterances());
