/*
 *  groupStyle.cpp
 *  openFrameworks
 *
 *  Created by Keith on 8/21/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "groupStyle.h"

