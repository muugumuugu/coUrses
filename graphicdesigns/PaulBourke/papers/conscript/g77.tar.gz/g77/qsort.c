#include <stdlib.h>
void qsort_(void *base, size_t nmemb, size_t size,
           int (*compar)(const void *, const void *))
{
  qsort (base, nmemb, size, compar);
}
