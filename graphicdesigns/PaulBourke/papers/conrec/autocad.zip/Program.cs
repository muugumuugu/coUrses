﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace ConRec
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("\n---------------------------------------------------");
			Console.WriteLine("                                                     ");
			Console.WriteLine("                ConRec a Contouring Package          ");
			Console.WriteLine("                C# Version coded : OxyPLot           ");
			Console.WriteLine("                Driver Routine J.M. Nichols          ");
			Console.WriteLine("                Version 1.0 Date: 9 Dec 2012         ");
			Console.WriteLine("                                                     ");
			Console.WriteLine("\n---------------------------------------------------");

			//	Declare the variables to control the plot screen limits from the XY 
			//  coordinates

			int pxmin;
			int pymin;
			int pxmax;
			int pymax;
			int nx = 512;
			int ny = 50;
			int nc = 9;
			int nl = 10;

			double[,] d = new double[nx + 1, ny + 1];
			double[] x = new double[nx + 1];
			double[] y = new double[ny + 1];
			double[] z = new double[nc + 1];
			double[] maxZ = new double[ny + 1];
			int[] locmaxZ = new int[ny + 1];
			//double X1, Y1, x2, y2;
			//double xdelta, ydelta, x3, y3, x4, y4;
			double zmin, zmax;
			//int i, j;
			int j;
			//double countx = 0.0;
			//double county = 0.0;
			double countny = System.Convert.ToDouble(ny);
			double countnx = System.Convert.ToDouble(nx);
			int ret = 0;


			//	Set variable values
			pxmin = 100;
			pymin = 100;
			pxmax = 612;
			pymax = 350;
			zmin = 1e30;
			zmax = -1e30;
			j = 0;


			Console.WriteLine("                                                     ");
			Console.WriteLine("    Program creates a DXF - Version AutoCAD R11      ");
			Console.WriteLine("    Why: This AutoCAD Version is plain vanilla.      ");
			Console.WriteLine("    Comments: 1. Nine contour levels                 ");
			Console.WriteLine("              2. Colour coded                        ");
			Console.WriteLine("              3. Contour layers Line-etc..           ");
			Console.WriteLine("                                                     ");
			Console.WriteLine("                                                     ");
			Console.WriteLine("\n---------------------------------------------------");


			// Create Files

			string pathE = @"FFTA-Cont.txt";
			string pathF = @"aCS.dxf";

			StreamWriter sw1 = File.CreateText(pathF);

			try
			{
				// Create an instance of StreamReader to read from a file. 
				// The using statement also closes the StreamReader. 
				using (StreamReader sr = new StreamReader(pathE))
				{
					string line;
					// Read and display lines from the file until the end of  
					// the file is reached. 
					double maxOld = 0.0;
					double maxOld1 = 0.0;
					int numold = -1;
					while ((line = sr.ReadLine()) != null)
					{
						//Console.WriteLine(line);
						
						string[] bits = line.Split(',');
						int num = int.Parse(bits[0]);
						if (num > numold)
						{
							numold = num;
							maxOld = 0.0;
						}
						double y1 = double.Parse(bits[1]);
						double z1 = double.Parse(bits[2]);
						d[j, num] = 1000.0 * z1;
						//Console.WriteLine("Record : {0} Num: {1} Frequency : {2,10:0.000000} Height : {3,10:0.000000} Max Height : {4,10:0.000000} Location : {5}", num, j, y1, d[j, num], maxZ[num], locmaxZ[num]);
						zmin = Math.Min(zmin, d[j, num]);
						zmax = Math.Max(zmax, d[j, num]);
						maxZ[num] = Math.Max(d[j, num], maxZ[num]);
						maxOld1 = maxZ[num] - maxOld;
						Console.WriteLine("d Value: {0,10:0.000000} Max Old {1,10:0.000000}  Max New {2,10:0.000000} Location {3}", d[j, num], maxOld, maxZ[num], locmaxZ[num]);
						if (maxOld1 > 0.0001)
						{
							locmaxZ[num] = j;
							maxOld = maxZ[num];
						}
						if (j == nx)
						{
							j = 0;
						}
						else
						{
							j = j + 1;
						}
					}
				}
			}
			catch (Exception e)
			{
				// Let the user know what went wrong.
				Console.WriteLine("The file could not be read:");
				Console.WriteLine(e.Message);
			}
			Console.WriteLine(" limits of the Heights zmin : {0}   zmax : {1}", zmin, zmax);

			for (int n = 0; n <= ny; n++)
			{
				double nn1 = System.Convert.ToDouble(n);
				// Places all the FFT's in a time sequence rising vertically
				y[n] = (nn1 * (pymax - pymin) / countny) + pymin;
				// Places all the FFT's in a time sequence falling vertically
				//y[n] = pymax - (System.Convert.ToDouble(n) * ((pymax - pymin) / countny));
				//Console.WriteLine("n: {0}  y[n] : {1}", n, y[n]);
			}
			for (int n = 0; n <= nx; n++)
			{
				double nn = System.Convert.ToDouble(n);
				x[n] = (nn * (pxmax - pxmin) / countnx) + pxmin;
				//Console.WriteLine("n: {0}  x[n] : {1}", n, x[n]);
			}

			for (int n = 1; n <= nc; n++)
			{
				double nn = System.Convert.ToDouble(n);
				double nc1 = System.Convert.ToDouble(nc);
				z[n] = nn * ((zmax - zmin) / (nc1 + 1.0));
				Console.WriteLine("n: {0}  z[n] : {1}", n, z[n]);
			}



			//  Output the DXF Data Header and Lines

			ret = DXFHeader(1, sw1);
			Console.WriteLine("Return Code is:  {0} ", ret);

			ret = DXFBorder(sw1, pxmin, pymin, pxmax, pymax, nl);
			Console.WriteLine("Return Code is:  {0} ", ret);

			ConRec(sw1, d, x, y, z);
			Console.WriteLine("Return Code is:  {0} ", ret);

			ret = MaxLine(sw1, pxmin, pymin, pxmax, pymax, maxZ, locmaxZ);
			Console.WriteLine("Return Code is:  {0} ", ret);
			ret = DXFHeader(2, sw1);
			Console.WriteLine("Return Code is:  {0} ", ret);
		}

		static int MaxLine(StreamWriter sw, double x1, double y1, double x2, double y2, double[] m, int[] mL)
		{
			int nc = mL.Length;
			double xS = 0.0;
			double yS = 0.0;
			double deltaY = (y2 - y1)/(nc-1);
			for (int i = 0; i < 51; i++)
			{
				Console.WriteLine(" i: {0}  m: {1}  Loc:  {2}", i, m[i], mL[i]);
				int ret;
				if (i < 1)
				{
					int iD = mL[i] + 100;
					double iD1 = Convert.ToDouble(iD);
					xS = iD1;
					yS = Convert.ToDouble(i);
					yS = yS * deltaY;
					yS = (yS*1.00) + 100;
				}
				else
				{
					int iD = mL[i] + 100;
					double iD1 = Convert.ToDouble(iD);
					double iD2 = Convert.ToDouble(i);
					iD2 = (iD2 * deltaY)*1.00 + 100.0;
					ret = VecOut(sw, xS, yS, iD1, iD2, 10);
					xS = iD1;
					yS = iD2;
				}
				

			}
				return 12;
		}
		static int DXFBorder(StreamWriter sw, double x1, double y1, double x2, double y2, int n)
		{
			int ret;
			ret = VecOut(sw, x1, y1, x1, y2, 0);
			ret = VecOut(sw, x1, y2, x2, y2, 0);
			ret = VecOut(sw, x2, y2, x2, y1, 0);
			ret = VecOut(sw, x1, y1, x2, y1, 0);
			double xdelta = (x2 - x1) / n;
			if (xdelta > 50.0)
			{
				xdelta = 50.0;
			}
			double ydelta = (y2 - y1) / n;
			Console.WriteLine("Grid Spacing : X:  {0}  Y: {1}",xdelta,ydelta);
			for (int j = 1; j <= 3; j++)
			{
				for (int i = 1; i <= n; i++)
				{
					double nn = System.Convert.ToDouble(i);
					double x3 = x1 + (xdelta * nn);
					double y3 = y1 + (ydelta * nn);
					ret = VecOut(sw, x3, y1, x3, y2, 0);
					if (j == 1)
					{
						ret = VecOut(sw, x1, y3, x2, y3, 0);
					}
					
				}
				if (j == 2)
				{
					xdelta = 5.0;
				}
				else
				{
					xdelta = 1.0;
				}
				
			}
			//double offsetX = 0.0;
			//double offsetY = -20;
			string Title1 = "FFT Output for GP2 Recorder";
			double size = 2.5;
			ret = TitleOut(sw, 100.0, 85.0, x1, y2, 0.0, Title1, size, 0);
			string Title2 = "CopyRight: J.M. Nichols 2012";
			double yDelta = y1 - 30;
			ret = TitleOut(sw, 100.0, 80.0, x1, y2, 0.0, Title2, size, 0);
			string datePatt = @"d/M/yyyy hh:mm:ss tt";
			DateTime saveUtcNow = DateTime.UtcNow;
			string Title3 = saveUtcNow.ToString(datePatt) + "  UTC";
			ret = TitleOut(sw, 100.0, 75.0, x1, y2, 0.0, Title3, size, 0);
			string Title4 = "FREQUENCY (Hertz)";
			size = 5.0;
			ret = TitleOut(sw, 325.0, 80, x1, y2, 0.0, Title4, size, 0);
			string Title7 = " Test Number";
			ret = TitleOut(sw, 80, 200, x1, y2, 90.0, Title7, size, 0);
			string Title8 = "Count of Data Points";
			size = 2.5;
			ret = TitleOut(sw, 100.0, 365.0, x1, y2, 0.0, Title8, size, 0);
			Console.WriteLine("Return Code is  {0}", ret);
			
			for (int i=0; i <= 550; i = i+50)
			{
				string Title5 = i.ToString();
				double iD;
				if (i == 550)
				{
					iD = 512 + 98;

					Title5 = "512";
				}
				else
				{
					iD = i + 98;
				}
				
				size = 2.5;
				ret = TitleOut(sw, iD, 360, x1, y2, 0.0, Title5, size, 0);
				Console.WriteLine("{0}", i);
			}

			for (int i = 5; i <= 45; i = i + 5)
			{
				string Title5 = i.ToString();
				double iD = i + 99;
				size = 1.5;
				ret = TitleOut(sw, iD, 360, x1, y2, 0.0, Title5, size, 0);
			}

			for (int j = 0; j <= 50; j = j + 5)
			{
				string Title6 = j.ToString();
				double iE = (5 * j) + 99;
				size = 2.5;
				ret = TitleOut(sw, 95, iE, x1, y2, 0.0, Title6, size, 0);

			}
			for (int k = 0; k <= 50; k = k + 5)
			{
				string Title9 = k.ToString();
				double iGA = (512.0 / 50.0);
				double kk =	Convert.ToDouble(k);
				double iGC = iGA * kk;
				double iG = iGC + 99.0;
				double iGR = iG + 1.0;
				Console.WriteLine("{0} {1} {2}", iG, iGA, kk);
				size = 2.5;
				ret = TitleOut(sw, iG, 90, x1, y2, 0.0, Title9, size, 0);
				ret = VecOut(sw, iGR, 100.0, iGR, 95.0, 0);
				ret = VecOut(sw, iGR, 350.0, iGR, 355.0, 0);
			}
			for (int k = 1; k <= 10; k++)
			{
				double kk = Convert.ToDouble(k);
				kk = 5.0 * kk - 2.5;
				double iGA = (512.0 / 50.0); double iGC = iGA * kk;
				double iG = iGC + 99.0;
				double iGR = iG + 1.0;
				Console.WriteLine("{0} {1} {2}", kk, iG, iGR);
				ret = VecOut(sw, iGR, 100.0, iGR, 95.0, 0);

			}
				return 5;
		}

		public static int TitleOut(StreamWriter sw, double x1, double y1, double x2, double y2, double ang, string text, double size, int layer)
		{
			int ret = 0;
			ret = Text1(sw, x1, y1, x2, y2, ang, text, size, layer);
			return 7;
		}
		

		static int Text1(StreamWriter sw, double x1, double y1, double x2, double y2, double ang, string text, double size, int layer)
		{
			//double size = 2.5;
			double z1 = 0.0;
			//string text1 = "Test";
			string text2 = "ConRec";
			Console.WriteLine("Inside Text1");
			sw.WriteLine("  0");
			sw.WriteLine("TEXT");
			sw.WriteLine("  8");
			sw.WriteLine("LSDGN");
			sw.WriteLine(" 10");
			sw.WriteLine("{0:F4}", x1);
			sw.WriteLine(" 20");
			sw.WriteLine("{0:F4}", y1);
			sw.WriteLine(" 30");
			sw.WriteLine("{0:F4}", z1);
			sw.WriteLine(" 40");
			sw.WriteLine("{0:F4}", size);
			sw.WriteLine("  1");
			sw.WriteLine(text);
			sw.WriteLine("  7");
			sw.WriteLine(text2);
			sw.WriteLine(" 50");
			sw.WriteLine("{0:F4}", ang);
			return 9;
		}
		// Text 1 but at 90 degrees
		static int Text2(StreamWriter sw, double x1, double y1, double x2, double y2, double ang, string text, double size, int layer)
		{
			//double size = 2.5;
			double z1 = 0.0;
			//string text1 = "Test";
			string text2 = "ConRec";
			Console.WriteLine("Inside Text1");
			sw.WriteLine("  0");
			sw.WriteLine("TEXT");
			sw.WriteLine("  8");
			sw.WriteLine("LSDGN");
			sw.WriteLine(" 10");
			sw.WriteLine("{0:F4}", x1);
			sw.WriteLine(" 20");
			sw.WriteLine("{0:F4}", y1);
			sw.WriteLine(" 30");
			sw.WriteLine("{0:F4}", z1);
			sw.WriteLine(" 40");
			sw.WriteLine("{0:F4}", size);
			sw.WriteLine("  1");
			sw.WriteLine(text);
			sw.WriteLine("  7");
			sw.WriteLine(text2);
			sw.WriteLine(" 50");
			sw.WriteLine("{0:F4}", ang);
			return 9;
		}
		static int VecOut(StreamWriter sw, double x1, double y1, double x2, double y2, int layer)
		{
			int ret = 0;
			ret = Draw(sw, x1, y1, x2, y2, layer);
			Console.WriteLine("Return Code is  {0}", ret);
			return 6;
		}

		static int Draw(StreamWriter sw, double x1, double y1, double x2, double y2, int layer)
		{

			sw.WriteLine("  0\nLINE\n999\nSubroutine Draw Layer : {0}", layer);
			sw.WriteLine("   8");
			//	Add the layer name to suit the contour level
			if (layer == 0)
			{
				String Layer = "Border";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n 84\n 10");
			}
			else if (layer == 1)
			{
				String Layer = "Contour-01";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n 44\n 10");
			}
			else if (layer == 2)
			{
				String Layer = "Contour-02";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  132\n 10");
			}
			else if (layer == 3)
			{
				String Layer = "Contour-03";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  180\n 10");
			}
			else if (layer == 4)
			{
				String Layer = "Contour-04";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  190\n 10");
			}
			else if (layer == 5)
			{
				String Layer = "Contour-05";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  200\n 10");
			}
			else if (layer == 6)
			{
				String Layer = "Contour-06";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  210\n 10");
			}
			else if (layer == 7)
			{
				String Layer = "Contour-07";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  220\n 10");
			}
			else if (layer == 8)
			{
				String Layer = "Contour-08";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  230\n 10");
			}
			else if (layer == 9)
			{
				String Layer = "Contour-09";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n  240\n 10");
			}
			else if (layer == 10)
			{
				String Layer = "Maximum Z Line";
				sw.WriteLine(Layer);
				sw.WriteLine(" 62\n    50\n 10");
			}
			else
			{
				String Layer = "Unknown";
				sw.WriteLine(Layer);
			}
			sw.WriteLine("{0:F20}", x1);
			sw.WriteLine("20\n{0:F20}", y1);
			sw.WriteLine("11\n{0:F20}", x2);
			sw.WriteLine("21\n{0:F20}", y2);

			return 11;
		}



		static int DXFHeader(int codeT, StreamWriter sw)
		{
			if (codeT == 1)
			{
				Console.WriteLine("   Create DXF File. ");
				sw.WriteLine("  0");
				sw.WriteLine("SECTION");
				sw.WriteLine("  2");
				sw.WriteLine("HEADER");
				sw.WriteLine("  9");
				sw.WriteLine("$TEXTSTYLE");
				sw.WriteLine("  7");
				sw.WriteLine("ConRec");
				sw.WriteLine(" 0");
				sw.WriteLine("ENDSEC");
				sw.WriteLine("  0");
				sw.WriteLine("SECTION");
				sw.WriteLine("  2");
				sw.WriteLine("CLASSES");
				sw.WriteLine(" 0");
				sw.WriteLine("ENDSEC");
				sw.WriteLine("  0");
				sw.WriteLine("SECTION");
				sw.WriteLine("  2");
				sw.WriteLine("TABLES");
				sw.WriteLine("  0");
				sw.WriteLine("TABLE");
				sw.WriteLine("  2");
				sw.WriteLine("STYLE");
				sw.WriteLine("  5");
				sw.WriteLine("3");
				sw.WriteLine("100");
				sw.WriteLine("AcDbSymbolTable");
				sw.WriteLine(" 70");
				sw.WriteLine("     3");
				sw.WriteLine("     0");
				sw.WriteLine("STYLE");
				sw.WriteLine("  5");
				sw.WriteLine("59");
				sw.WriteLine("100");
				sw.WriteLine("AcDbSymbolTableRecord");
				sw.WriteLine("100");
				sw.WriteLine("AcDbTextStyleTableRecord");
				sw.WriteLine("  2");
				sw.WriteLine("Annotative");
				sw.WriteLine(" 70");
				sw.WriteLine("     0");
				//sw.WriteLine("STYLE");
				//sw.WriteLine("  5");
				//sw.WriteLine("59");
				//sw.WriteLine("100");
				//sw.WriteLine("AcDbSymbolTableRecord");
				//sw.WriteLine("100");
				//sw.WriteLine("AcDbTextStyleTableRecord");
				//sw.WriteLine("  2");
				//sw.WriteLine("Annotative");
				//sw.WriteLine(" 70");
				//sw.WriteLine("    0");
				sw.WriteLine(" 40");
				sw.WriteLine("0.0");
				sw.WriteLine(" 41");
				sw.WriteLine("1.0");
				sw.WriteLine(" 50");
				sw.WriteLine("0.0");
				sw.WriteLine(" 71");
				sw.WriteLine("    0");
				sw.WriteLine(" 42");
				sw.WriteLine(" 0.2");
				sw.WriteLine("  3");
				sw.WriteLine("txt");
				sw.WriteLine("  4");
				sw.WriteLine("");
				sw.WriteLine("  0");
				sw.WriteLine("STYLE");
				sw.WriteLine("  5");
				sw.WriteLine("CD");
				sw.WriteLine("100");
				sw.WriteLine("AcDbSymbolTableRecord");
				sw.WriteLine("100");
				sw.WriteLine("AcDbTextStyleTableRecord");
				sw.WriteLine("  2");
				sw.WriteLine("CONREC");
				sw.WriteLine(" 70");
				sw.WriteLine("     0");
				sw.WriteLine("40");
				sw.WriteLine("0.0");
				sw.WriteLine(" 41");
				sw.WriteLine("1.0");
				sw.WriteLine(" 50");
				sw.WriteLine("0.0");
				sw.WriteLine("71");
				sw.WriteLine("    0");
				sw.WriteLine(" 42");
				sw.WriteLine("2.5");
				sw.WriteLine("  3");
				sw.WriteLine("complex.shx");
				sw.WriteLine("  4");
				sw.WriteLine("");
				sw.WriteLine("  0");
				sw.WriteLine("ENDTAB");
				sw.WriteLine(" 0\nENDSEC\n  0\nSECTION\n  2\nENTITIES");
				sw.Flush();
				return 1;
			}
			if (codeT == 2)
			{
				sw.WriteLine(" 0\nENDSEC\n  0\nEOF");
				sw.Flush();
				return 2;
			}
			return 3;

		}


		static void ConRec(StreamWriter sw, double[,] d, double[] x, double[] y, double[] z)
		{
			Console.WriteLine(" Inside ConRec");
			{
				double x1 = 0.0;
				double x2 = 0.0;
				double y1 = 0.0;
				double y2 = 0.0;

				var h = new double[5];
				var sh = new int[5];
				var xh = new double[5];
				var yh = new double[5];

				int ilb = d.GetLowerBound(0);
				int iub = d.GetUpperBound(0);
				int jlb = d.GetLowerBound(1);
				int jub = d.GetUpperBound(1);
				int nc = z.Length;

				// The indexing of im and jm should be noted as it has to start from zero
				// unlike the fortran counter part
				int[] im = { 0, 1, 1, 0 };
				int[] jm = { 0, 0, 1, 1 };

				// Note that castab is arranged differently from the FORTRAN code because
				// Fortran and C/C++ arrays are transposed of each other, in this case
				// it is more tricky as castab is in 3 dimension
				int[, ,] castab = {
								 { { 0, 0, 8 }, { 0, 2, 5 }, { 7, 6, 9 } }, { { 0, 3, 4 }, { 1, 3, 1 }, { 4, 3, 0 } }, 
								 { { 9, 6, 7 }, { 5, 2, 0 }, { 8, 0, 0 } }
							 };

				Func<int, int, double> xsect = (p1, p2) => (h[p2] * xh[p1] - h[p1] * xh[p2]) / (h[p2] - h[p1]);
				Func<int, int, double> ysect = (p1, p2) => (h[p2] * yh[p1] - h[p1] * yh[p2]) / (h[p2] - h[p1]);

				for (int j = jub - 1; j >= jlb; j--)
				{
					int i;
					for (i = ilb; i <= iub - 1; i++)
					{
						double temp1 = Math.Min(d[i, j], d[i, j + 1]);
						double temp2 = Math.Min(d[i + 1, j], d[i + 1, j + 1]);
						double dmin = Math.Min(temp1, temp2);
						temp1 = Math.Max(d[i, j], d[i, j + 1]);
						temp2 = Math.Max(d[i + 1, j], d[i + 1, j + 1]);
						double dmax = Math.Max(temp1, temp2);

						if (dmax >= z[0] && dmin <= z[nc - 1])
						{
							int k;
							for (k = 0; k < nc; k++)
							{
								if (z[k] >= dmin && z[k] <= dmax)
								{
									int m;
									for (m = 4; m >= 0; m--)
									{
										if (m > 0)
										{
											// The indexing of im and jm should be noted as it has to
											// start from zero
											h[m] = d[i + im[m - 1], j + jm[m - 1]] - z[k];
											xh[m] = x[i + im[m - 1]];
											yh[m] = y[j + jm[m - 1]];
										}
										else
										{
											h[0] = 0.25 * (h[1] + h[2] + h[3] + h[4]);
											xh[0] = 0.5 * (x[i] + x[i + 1]);
											yh[0] = 0.5 * (y[j] + y[j + 1]);
										}

										if (h[m] > 0.0)
										{
											sh[m] = 1;
										}
										else if (h[m] < 0.0)
										{
											sh[m] = -1;
										}
										else
										{
											sh[m] = 0;
										}
									}

									// Note: at this stage the relative heights of the corners and the
									// centre are in the h array, and the corresponding coordinates are
									// in the xh and yh arrays. The centre of the box is indexed by 0
									// and the 4 corners by 1 to 4 as shown below.
									// Each triangle is then indexed by the parameter m, and the 3
									// vertices of each triangle are indexed by parameters m1,m2,and
									// m3.
									// It is assumed that the centre of the box is always vertex 2
									// though this isimportant only when all 3 vertices lie exactly on
									// the same contour level, in which case only the side of the box
									// is drawn.
									// vertex 4 +-------------------+ vertex 3
									// | \               / |
									// |   \    m-3    /   |
									// |     \       /     |
									// |       \   /       |
									// |  m=2    X   m=2   |       the centre is vertex 0
									// |       /   \       |
									// |     /       \     |
									// |   /    m=1    \   |
									// | /               \ |
									// vertex 1 +-------------------+ vertex 2
									// Scan each triangle in the box
									for (m = 1; m <= 4; m++)
									{
										int m1 = m;
										int m2 = 0;
										int m3;
										if (m != 4)
										{
											m3 = m + 1;
										}
										else
										{
											m3 = 1;
										}

										int caseValue = castab[sh[m1] + 1, sh[m2] + 1, sh[m3] + 1];
										if (caseValue != 0)
										{
											switch (caseValue)
											{
												case 1: // Line between vertices 1 and 2
													x1 = xh[m1];
													y1 = yh[m1];
													x2 = xh[m2];
													y2 = yh[m2];
													break;
												case 2: // Line between vertices 2 and 3
													x1 = xh[m2];
													y1 = yh[m2];
													x2 = xh[m3];
													y2 = yh[m3];
													break;
												case 3: // Line between vertices 3 and 1
													x1 = xh[m3];
													y1 = yh[m3];
													x2 = xh[m1];
													y2 = yh[m1];
													break;
												case 4: // Line between vertex 1 and side 2-3
													x1 = xh[m1];
													y1 = yh[m1];
													x2 = xsect(m2, m3);
													y2 = ysect(m2, m3);
													break;
												case 5: // Line between vertex 2 and side 3-1
													x1 = xh[m2];
													y1 = yh[m2];
													x2 = xsect(m3, m1);
													y2 = ysect(m3, m1);
													break;
												case 6: // Line between vertex 3 and side 1-2
													x1 = xh[m3];
													y1 = yh[m3];
													x2 = xsect(m1, m2);
													y2 = ysect(m1, m2);
													break;
												case 7: // Line between sides 1-2 and 2-3
													x1 = xsect(m1, m2);
													y1 = ysect(m1, m2);
													x2 = xsect(m2, m3);
													y2 = ysect(m2, m3);
													break;
												case 8: // Line between sides 2-3 and 3-1
													x1 = xsect(m2, m3);
													y1 = ysect(m2, m3);
													x2 = xsect(m3, m1);
													y2 = ysect(m3, m1);
													break;
												case 9: // Line between sides 3-1 and 1-2
													x1 = xsect(m3, m1);
													y1 = ysect(m3, m1);
													x2 = xsect(m1, m2);
													y2 = ysect(m1, m2);
													break;
												default:
													break;
											}
											//Console.WriteLine("{0}  {1}  {2}  {3}  {4} ", x1, y1, x2, y2, z[k]);
											int ret = 0;
											ret = Draw(sw, x1, y1, x2, y2, k);
											//renderer(x1, y1, x2, y2, z[k]);
										}
									}
								}
							}
						}
					}
					
				}
			}
		}
	}
}


