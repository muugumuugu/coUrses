﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Triangulation
{
    static class Program
    {
        /// <summary>
        /// Punto di ingresso principale dell'applicazione.
        /// </summary>
        [STAThread]
        static void Main()
        {/*
            Vector2[] vertices = new Vector2[200 * 200];
            for (int y = 0; y < 200; ++y)
            {
                for (int x = 0; x < 200; ++x)
                {
                    vertices[x + y * 200] = new Vector2(x * 10, y * 10);
                }
            }

            Delaunay2D.Triangulate(vertices, 0.00001f);

            return;*/

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}