using System;
using System.Collections.Generic;
using System.Text;

namespace Triangulation
{
    public struct IntegerTriangle
    {
        public int A;
        public int B;
        public int C;
    }
}
