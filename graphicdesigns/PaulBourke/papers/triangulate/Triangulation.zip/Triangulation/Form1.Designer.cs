﻿namespace Triangulation
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAddEnormousGrid = new System.Windows.Forms.Button();
            this.lblTriangulationTime = new System.Windows.Forms.Label();
            this.lblTrianglesCount = new System.Windows.Forms.Label();
            this.lblPointsCount = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddSmallGrid = new System.Windows.Forms.Button();
            this.btnAddBigGrid = new System.Windows.Forms.Button();
            this.chkAutoTriangulate = new System.Windows.Forms.CheckBox();
            this.btnTriangulate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.pnlTriangulation = new System.Windows.Forms.Panel();
            this.chkDrawPoints = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chkDrawPoints);
            this.panel1.Controls.Add(this.btnAddEnormousGrid);
            this.panel1.Controls.Add(this.lblTriangulationTime);
            this.panel1.Controls.Add(this.lblTrianglesCount);
            this.panel1.Controls.Add(this.lblPointsCount);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnAddSmallGrid);
            this.panel1.Controls.Add(this.btnAddBigGrid);
            this.panel1.Controls.Add(this.chkAutoTriangulate);
            this.panel1.Controls.Add(this.btnTriangulate);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 395);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(579, 92);
            this.panel1.TabIndex = 0;
            // 
            // btnAddEnormousGrid
            // 
            this.btnAddEnormousGrid.Location = new System.Drawing.Point(304, 6);
            this.btnAddEnormousGrid.Name = "btnAddEnormousGrid";
            this.btnAddEnormousGrid.Size = new System.Drawing.Size(108, 23);
            this.btnAddEnormousGrid.TabIndex = 11;
            this.btnAddEnormousGrid.Text = "Add enormous grid";
            this.btnAddEnormousGrid.UseVisualStyleBackColor = true;
            this.btnAddEnormousGrid.Click += new System.EventHandler(this.btnAddEnormousGrid_Click);
            // 
            // lblTriangulationTime
            // 
            this.lblTriangulationTime.AutoSize = true;
            this.lblTriangulationTime.Location = new System.Drawing.Point(344, 43);
            this.lblTriangulationTime.Name = "lblTriangulationTime";
            this.lblTriangulationTime.Size = new System.Drawing.Size(29, 13);
            this.lblTriangulationTime.TabIndex = 10;
            this.lblTriangulationTime.Text = "0 ms";
            // 
            // lblTrianglesCount
            // 
            this.lblTrianglesCount.AutoSize = true;
            this.lblTrianglesCount.Location = new System.Drawing.Point(178, 43);
            this.lblTrianglesCount.Name = "lblTrianglesCount";
            this.lblTrianglesCount.Size = new System.Drawing.Size(13, 13);
            this.lblTrianglesCount.TabIndex = 9;
            this.lblTrianglesCount.Text = "0";
            // 
            // lblPointsCount
            // 
            this.lblPointsCount.AutoSize = true;
            this.lblPointsCount.Location = new System.Drawing.Point(58, 43);
            this.lblPointsCount.Name = "lblPointsCount";
            this.lblPointsCount.Size = new System.Drawing.Size(13, 13);
            this.lblPointsCount.TabIndex = 8;
            this.lblPointsCount.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(242, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Triangulation time :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(116, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Triangles :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Points :";
            // 
            // btnAddSmallGrid
            // 
            this.btnAddSmallGrid.Location = new System.Drawing.Point(106, 6);
            this.btnAddSmallGrid.Name = "btnAddSmallGrid";
            this.btnAddSmallGrid.Size = new System.Drawing.Size(93, 23);
            this.btnAddSmallGrid.TabIndex = 4;
            this.btnAddSmallGrid.Text = "Add small grid";
            this.btnAddSmallGrid.UseVisualStyleBackColor = true;
            this.btnAddSmallGrid.Click += new System.EventHandler(this.btnAddSmallGrid_Click);
            // 
            // btnAddBigGrid
            // 
            this.btnAddBigGrid.Location = new System.Drawing.Point(205, 6);
            this.btnAddBigGrid.Name = "btnAddBigGrid";
            this.btnAddBigGrid.Size = new System.Drawing.Size(93, 23);
            this.btnAddBigGrid.TabIndex = 3;
            this.btnAddBigGrid.Text = "Add big grid";
            this.btnAddBigGrid.UseVisualStyleBackColor = true;
            this.btnAddBigGrid.Click += new System.EventHandler(this.btnAddBigGrid_Click);
            // 
            // chkAutoTriangulate
            // 
            this.chkAutoTriangulate.AutoSize = true;
            this.chkAutoTriangulate.Checked = true;
            this.chkAutoTriangulate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAutoTriangulate.Location = new System.Drawing.Point(439, 42);
            this.chkAutoTriangulate.Name = "chkAutoTriangulate";
            this.chkAutoTriangulate.Size = new System.Drawing.Size(96, 17);
            this.chkAutoTriangulate.TabIndex = 2;
            this.chkAutoTriangulate.Text = "autotriangulate";
            this.chkAutoTriangulate.UseVisualStyleBackColor = true;
            this.chkAutoTriangulate.CheckedChanged += new System.EventHandler(this.chkAutoTriangulate_CheckedChanged);
            // 
            // btnTriangulate
            // 
            this.btnTriangulate.Location = new System.Drawing.Point(439, 6);
            this.btnTriangulate.Name = "btnTriangulate";
            this.btnTriangulate.Size = new System.Drawing.Size(75, 23);
            this.btnTriangulate.TabIndex = 1;
            this.btnTriangulate.Text = "triangulate!";
            this.btnTriangulate.UseVisualStyleBackColor = true;
            this.btnTriangulate.Click += new System.EventHandler(this.btnTriangulate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(7, 6);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(93, 23);
            this.btnClear.TabIndex = 0;
            this.btnClear.Text = "clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // pnlTriangulation
            // 
            this.pnlTriangulation.BackColor = System.Drawing.Color.White;
            this.pnlTriangulation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTriangulation.Location = new System.Drawing.Point(0, 0);
            this.pnlTriangulation.Name = "pnlTriangulation";
            this.pnlTriangulation.Size = new System.Drawing.Size(579, 395);
            this.pnlTriangulation.TabIndex = 2;
            this.pnlTriangulation.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlTriangulation_Paint);
            this.pnlTriangulation.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            this.pnlTriangulation.Resize += new System.EventHandler(this.panel2_Resize);
            // 
            // chkDrawPoints
            // 
            this.chkDrawPoints.AutoSize = true;
            this.chkDrawPoints.Checked = true;
            this.chkDrawPoints.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkDrawPoints.Location = new System.Drawing.Point(439, 65);
            this.chkDrawPoints.Name = "chkDrawPoints";
            this.chkDrawPoints.Size = new System.Drawing.Size(80, 17);
            this.chkDrawPoints.TabIndex = 12;
            this.chkDrawPoints.Text = "draw points";
            this.chkDrawPoints.UseVisualStyleBackColor = true;
            this.chkDrawPoints.CheckedChanged += new System.EventHandler(this.chkDrawPoints_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 487);
            this.Controls.Add(this.pnlTriangulation);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Panel pnlTriangulation;
        private System.Windows.Forms.Button btnTriangulate;
        private System.Windows.Forms.CheckBox chkAutoTriangulate;
        private System.Windows.Forms.Button btnAddBigGrid;
        private System.Windows.Forms.Button btnAddSmallGrid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTriangulationTime;
        private System.Windows.Forms.Label lblTrianglesCount;
        private System.Windows.Forms.Label lblPointsCount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAddEnormousGrid;
        private System.Windows.Forms.CheckBox chkDrawPoints;
    }
}

