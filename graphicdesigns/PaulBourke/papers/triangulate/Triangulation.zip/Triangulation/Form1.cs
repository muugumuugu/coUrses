using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace Triangulation
{
    public partial class Form1 : Form
    {
        public List<Vector2> vertices = new List<Vector2>();
        public IntegerTriangle[] triangulation;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            vertices.Add(new Vector2(e.X, e.Y));
            this.UpdateTriangulation(this.chkAutoTriangulate.Checked);
        }

        private void panel2_Resize(object sender, EventArgs e)
        {
            this.pnlTriangulation.Invalidate();
        }

        public void AddGrid(int width, int height, float scale)
        {
            for (int y = 0; y < height; ++y)
                for (int x = 0; x < width; ++x)
                    this.vertices.Add(new Vector2(x * scale, y * scale));

            this.UpdateTriangulation(this.chkAutoTriangulate.Checked);
        }

        private void btnAddSmallGrid_Click(object sender, EventArgs e)
        {
            this.AddGrid(20, 20, 30.0f);
        }

        private void btnAddBigGrid_Click(object sender, EventArgs e)
        {
            this.AddGrid(64, 64, 14.0f);
        }


        private void btnAddEnormousGrid_Click(object sender, EventArgs e)
        {
            this.AddGrid(256, 256, 9.5f);
        }
        public void UpdateTriangulation(bool triangulate)
        {
            if (triangulate)
            {
                this.triangulation = null;

                Stopwatch sw = new Stopwatch();
                sw.Start();
                this.triangulation = Delaunay2D.Triangulate(this.vertices, 0.00001f);
                sw.Stop();
                this.lblTriangulationTime.Text = sw.Elapsed.TotalMilliseconds.ToString("F3") + " ms";

                this.pnlTriangulation.Invalidate();
            }
            else
            {
                this.triangulation = null;
                this.lblTriangulationTime.Text = "-";
                this.pnlTriangulation.Invalidate();
            }

            this.lblPointsCount.Text = this.vertices.Count.ToString();
            this.lblTrianglesCount.Text = this.triangulation == null ? "0" : this.triangulation.Length.ToString();
        }

        private void chkAutoTriangulate_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkAutoTriangulate.Checked)
                this.UpdateTriangulation(true);
        }

        private void pnlTriangulation_Paint(object sender, PaintEventArgs e)
        {
            if (this.triangulation != null)
            {
                foreach (IntegerTriangle t in this.triangulation)
                {
                    e.Graphics.DrawLine(Pens.Black, this.vertices[t.A].X, this.vertices[t.A].Y, this.vertices[t.B].X, this.vertices[t.B].Y);
                    e.Graphics.DrawLine(Pens.Black, this.vertices[t.B].X, this.vertices[t.B].Y, this.vertices[t.C].X, this.vertices[t.C].Y);
                    e.Graphics.DrawLine(Pens.Black, this.vertices[t.C].X, this.vertices[t.C].Y, this.vertices[t.A].X, this.vertices[t.A].Y);
                }
            }

            if (this.chkDrawPoints.Checked)
            {
                foreach (Vector2 v in this.vertices)
                {
                    e.Graphics.FillEllipse(Brushes.Red, new System.Drawing.RectangleF(v.X - 4, v.Y - 4, 8, 8));
                }
            }
        }

        private void btnTriangulate_Click(object sender, EventArgs e)
        {
            this.UpdateTriangulation(true);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            vertices.Clear();
            this.UpdateTriangulation(false);
        }

        private void chkDrawPoints_CheckedChanged(object sender, EventArgs e)
        {
            this.pnlTriangulation.Invalidate();
        }
    }
}