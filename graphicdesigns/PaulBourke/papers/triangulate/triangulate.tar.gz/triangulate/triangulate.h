
#define DTOR 0.01745329252
#define ABS(x) ( (x) < 0 ? -(x) : (x) )
#define MIN(x,y) ( x < y ? x : y )
#define MAX(x,y) ( x < y ? y : x )
#define MODULUS(p) (sqrt((p).x * (p).x + (p).y * (p).y + (p).z * (p).z) )
#define SIGN(x) ( x < 0 ? -1 : 1 )
#define DOTPRODUCT(v1,v2) ( v1.x*v2.x + v1.y*v2.y + v1.z*v2.z )
#define INVERTVECTOR(p1) p1.x = -p1.x; p1.y = -p1.y; p1.z = -p1.z
#define CROSSPROD(p1,p2,p3) p3.x = p1.y*p2.z - p1.z*p2.y;p3.y = p1.z*p2.x - p1.x*p2.z;p3.z = p1.x*p2.y - p1.y*p2.x

#define FALSE 0
#define TRUE 1

#define EPSILON		0.0001	   /* small float for vertex closeness	*/
#define INFINITY       	1.0E10     /* representation of infinity	*/

typedef struct {
  double x,y,z;
} XYZ;

typedef struct TRIANGLE {
  short p1,p2,p3;
} TRIANGLE;

typedef struct EDGE {
  short p1,p2;
} EDGE;

typedef struct {
  double a,b,c,d;
} PLANE;
