'Credit to Paul Bourke (pbourke@swin.edu.au) for the original Fortran 77 Program :))
'Converted from the VB-Conversion by EluZioN (EluZioN@casesladder.com)
'Check out: http://astronomy.swin.edu.au/~pbourke/terrain/triangulate/
'You can use this code however you like providing the above credits remain in tact

Option Strict Off
Option Explicit On
Friend Class Form1
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Picture1 As System.Windows.Forms.PictureBox
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents lblTris As System.Windows.Forms.Label
	Public WithEvents lblPoints As System.Windows.Forms.Label
	Public WithEvents mnuexit As System.Windows.Forms.MenuItem
	Public WithEvents mnufile As System.Windows.Forms.MenuItem
	Public WithEvents mnuabout As System.Windows.Forms.MenuItem
	Public MainMenu1 As System.Windows.Forms.MainMenu
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Picture1 = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblTris = New System.Windows.Forms.Label
        Me.lblPoints = New System.Windows.Forms.Label
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.mnufile = New System.Windows.Forms.MenuItem
        Me.mnuexit = New System.Windows.Forms.MenuItem
        Me.mnuabout = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'Picture1
        '
        Me.Picture1.BackColor = System.Drawing.Color.White
        Me.Picture1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Picture1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Picture1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Picture1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Picture1.Location = New System.Drawing.Point(8, 40)
        Me.Picture1.Name = "Picture1"
        Me.Picture1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Picture1.Size = New System.Drawing.Size(449, 329)
        Me.Picture1.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(280, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(177, 25)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Click The Pic Box to add points"
        '
        'lblTris
        '
        Me.lblTris.BackColor = System.Drawing.SystemColors.Control
        Me.lblTris.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTris.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTris.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblTris.Location = New System.Drawing.Point(136, 8)
        Me.lblTris.Name = "lblTris"
        Me.lblTris.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTris.Size = New System.Drawing.Size(129, 25)
        Me.lblTris.TabIndex = 2
        '
        'lblPoints
        '
        Me.lblPoints.BackColor = System.Drawing.SystemColors.Control
        Me.lblPoints.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblPoints.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPoints.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblPoints.Location = New System.Drawing.Point(8, 8)
        Me.lblPoints.Name = "lblPoints"
        Me.lblPoints.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblPoints.Size = New System.Drawing.Size(97, 25)
        Me.lblPoints.TabIndex = 1
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnufile, Me.mnuabout})
        '
        'mnufile
        '
        Me.mnufile.Index = 0
        Me.mnufile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuexit})
        Me.mnufile.Text = "&File"
        '
        'mnuexit
        '
        Me.mnuexit.Index = 0
        Me.mnuexit.Text = "Exit"
        '
        'mnuabout
        '
        Me.mnuabout.Index = 1
        Me.mnuabout.Text = "&About"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(469, 379)
        Me.Controls.Add(Me.Picture1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblTris)
        Me.Controls.Add(Me.lblPoints)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Location = New System.Drawing.Point(11, 49)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "Triangulate"
        Me.ResumeLayout(False)

    End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As Form1
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As Form1
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New Form1()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region

    Dim tPoints As Short 'Variable for total number of points (vertices)

    Private Sub Form1_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        'Initiate total points to 1, using base 0 causes problems in the functions
        tPoints = 1
    End Sub

    Public Sub mnuabout_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuabout.Popup
        mnuabout_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuabout_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuabout.Click
        frmAbout.DefInstance.Show()
    End Sub

    Public Sub mnuexit_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuexit.Popup
        mnuexit_Click(eventSender, eventArgs)
    End Sub
    Public Sub mnuexit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles mnuexit.Click
        End
    End Sub

    Private Sub Picture1_MouseDown(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.MouseEventArgs) Handles Picture1.MouseDown

        'Draw line on picturebox
        'Put a picturebox on the form named pic

        Dim bit As Bitmap = New Bitmap(Picture1.Width, Picture1.Height)
        Dim g As Graphics = Graphics.FromImage(bit)
        Dim myPen As Pen = New Pen(Color.Blue, 1)

        Dim Button As Short = eventArgs.Button \ &H100000
        Dim Shift As Short = System.Windows.Forms.Control.ModifierKeys \ &H10000
        Dim x As Single = eventArgs.X
        Dim y As Single = eventArgs.Y
        Dim i As Object

        'variable to hold how many triangles are created by the triangulate function
        Dim HowMany As Short

        'Set Vertex coordinates where you clicked the pic box
        Vertex(tPoints).x = x
        Vertex(tPoints).y = y

        'Perform Triangulation Function if there are more than 2 points
        If tPoints > 2 Then
            'Clear the Picture Box
            Picture1.Refresh()
            'Returns number of triangles created.
            HowMany = Triangulate(tPoints)
        Else
            'Draw a circle where you clicked so it does something
            'g.DrawRectangle(myPen, Vertex(tPoints).x, Vertex(tPoints).y, 14, 14)
            g.DrawEllipse(myPen, Vertex(tPoints).x, Vertex(tPoints).y, 4, 4)
        End If

        'Display the total points and total triangles
        lblPoints.Text = "Points: " & tPoints
        lblTris.Text = "Triangles: " & HowMany


        'Increment the total number of points
        tPoints = tPoints + 1

        'Draw the created triangles
        For i = 1 To HowMany
            g.DrawLine(myPen, Vertex(Triangle(i).vv0).x, Vertex(Triangle(i).vv0).y, Vertex(Triangle(i).vv1).x, Vertex(Triangle(i).vv1).y)
            g.DrawLine(myPen, Vertex(Triangle(i).vv1).x, Vertex(Triangle(i).vv1).y, Vertex(Triangle(i).vv2).x, Vertex(Triangle(i).vv2).y)
            g.DrawLine(myPen, Vertex(Triangle(i).vv0).x, Vertex(Triangle(i).vv0).y, Vertex(Triangle(i).vv2).x, Vertex(Triangle(i).vv2).y)
        Next i

        Picture1.Image = bit


    End Sub

End Class