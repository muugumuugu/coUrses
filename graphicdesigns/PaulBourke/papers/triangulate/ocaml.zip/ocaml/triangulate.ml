(*
	Credit to Paul Bourke (pbourke@swin.edu.au) for the original Fortran 77 Program :))
	Conversion to Visual Basic by EluZioN (EluZioN@casesladder.com)
	Conversion from VB to Delphi6 by Dr Steve Evans (steve@lociuk.com)

	///////////////////////////////////////////////////////////////////////////////
	//June 2002 Update by Dr Steve Evans (steve@lociuk.com): Heap memory allocation
	//added to prevent stack overflow when MaxVertices and MaxTriangles are very large.
	//Additional Updates in June 2002:
	//Bug in InCircle function fixed. Radius r := Sqrt(rsqr).
	//Check for duplicate points added when inserting new point.
	//For speed, all points pre-sorted in x direction using quicksort algorithm and
	//triangles flagged when no longer needed. The circumcircle centre and radius of
	//the triangles are now stored to improve calculation time.
	///////////////////////////////////////////////////////////////////////////////

	May 2003 Conversion from VB to OCaml by MSc Andr� Luiz Moura (aluizmoura@yahoo.com.br)
  Additional Updates in May 2003:
  Generate random points defined by parameter in command line:
  Triangulate [max_random_points]

	//You can use this code however you like providing the above credits remain in tact
*)

(* 15/05/2003 - 7h46 *)
(* Clean the white panel *)
let apague_painel x1 y1 x2 y2 cor =
  Graphics.set_color cor;
  Graphics.fill_rect x1 y1 x2 y2;;
(*val apague_painel : int -> int -> int -> int -> Graphics.color -> unit =
  <fun>
*)

(* Points (Vertices) *)
type dVertex = {
	mutable x : int;
  mutable y : int
};;

(* Created Triangles, vv# are the vertex pointers *)
type dTriangle = {
	mutable vv0 : int;
  mutable vv1 : int;
  mutable vv2 : int
};;

(* Set these as applicable *)
let maxVertices = 100000;;
let maxTriangles = 200000;;

(* 30/04/2003 - 16h12 *)
(* Initiate total points to 1, using base 0 causes problems in the functions *)
let tPoints = ref 1;;
let howMany = ref 0;;

(* Allocate memory for arrays *)
let vertex = Array.make maxVertices {x=(-1); y=(-1)};;
let triangle = Array.make maxTriangles {vv0=(-1); vv1=(-1); vv2=(-1)};;
let complete = Array.make maxTriangles false
and edges = Array.make_matrix 2 (maxTriangles*3) (-1)

and nedge = ref (-1);;

(* 15/05/2003 - 9h13 *)
let tInic, tFin = ref 0.0, ref 0.0;;

(* 15/05/2003 - 7h54 *)
(* Generate random points and save it in vertex array *)
let gerePontosRand limX limY quant =
	Random.self_init ();
  for i=0 to quant-1 do
  	vertex.(i) <- {x=(Random.int (limX-1))+1; y=(Random.int (limY-1))+1};
  done;;
(*val gerePontosRand : int -> int -> int -> unit = <fun>*)


(* Sort all points by x *)
let rec doQuickSort a iLo iHi =
	let lo, hi = ref 0, ref 0
  and mid = ref 0
  and t = ref {x=(-1); y=(-1)} in
  lo := iLo;
  hi := iHi;
  mid := a.((!lo + !hi) / 2).x;

  while lo <= hi do
  	while a.(!lo).x < !mid do
    	incr lo
    done;
    while a.(!hi).x > !mid do
    	decr hi
    done;
    if !lo <= !hi then begin
    	t := a.(!lo);
      a.(!lo) <- a.(!hi);
      a.(!hi) <- !t;
      incr lo;
      decr hi
    end;
  done;
  if !hi > iLo then
  	doQuickSort a iLo !hi;
  if !lo < iHi then
	doQuickSort a !lo iHi;;
(*val doQuickSort : dVertex array -> int -> int -> unit = <fun>*)

let quicksort a low high =
	doQuickSort a low high;;
(*val quicksort : dVertex array -> int -> int -> unit = <fun>*)


(* 15/05/2003 - 8h52 *)
exception Arg of int  (* Ver Cap. 7 de Introduction to Objective OCaml *)
exception Usage

(* *)
let getarg() =
	if Array.length Sys.argv < 2 then
  	raise Usage
  else
  	raise (Arg(int_of_string Sys.argv.(1)))

let _ = try getarg() with
	Usage -> Printf.printf "Usage: Triangulate [num_points]\n"

  (* 18/05/2003 - 21h40 *)
  | Arg(i) -> gerePontosRand 500 350 i; tPoints := !tPoints + i
  | Failure xs -> Printf.printf "The value must to be integer\n";;
(*val getarg : unit -> 'a = <fun>*)

(* 29/04/2003 - 15h12 *)
(* Global variables *)
let xC = ref 0.0;;
let yC = ref 0.0;;
let radix = ref 0.0;;

(*
	Return TRUE if the point (xp,yp) lies inside the circumcircle
	made up by points (x1,y1) (x2,y2) (x3,y3)
  The circumcircle centre is returned in (xc,yc) and the radius r
  NOTE: A point on the edge is inside the circumcircle
*)
let inCircle xp yp x1 y1 x2 y2 x3 y3 =
	let eps    = ref 0.0
  and m1     = ref 0.0
  and m2     = ref 0.0
  and mx1    = ref 0.0
  and mx2    = ref 0.0
  and my1    = ref 0.0
  and my2    = ref 0.0
  and dx     = ref 0.0
  and dy     = ref 0.0
  and rsqr   = ref 0.0
  and drsqr  = ref 0.0 in

  eps := 0.000001;

  if (float_of_int (abs (y1 - y2))) < !eps && (float_of_int (abs (y2 - y3))) < !eps then begin
    Printf.printf "INCIRCUM - F - Points are coincident !!\n";
    false
  end
  else begin
  	if (float_of_int (abs (y2 - y1))) < !eps then begin
    	m2  := (float_of_int ((x3 - x2) * (-1))) /. (float_of_int (y3 - y2));
      mx2 := (float_of_int (x2 + x3)) /. 2.0;
      my2 := (float_of_int (y2 + y3)) /. 2.0;
      xC  := (float_of_int (x2 + x1)) /. 2.0;
      yC 	:= !m2 *. (!xC -. !mx2) +. !my2
    end  (* Fim if *)
    else if (float_of_int (abs (y3 - y2))) < !eps then begin
    	m1  := (float_of_int ((x2 - x1) * (-1))) /. (float_of_int (y2 - y1));
      mx1 := (float_of_int (x1 + x2)) /. 2.0;
      my1 := (float_of_int(y1 + y2)) /. 2.0;
      xC  := (float_of_int(x3 + x2)) /. 2.0;
      yC  := !m1 *. (!xC -. !mx1) +. !my1
    end  (* Fim else if *)
    else begin
    	m1  := (float_of_int ((x2 - x1) * (-1))) /. (float_of_int (y2 - y1));
      m2  := (float_of_int ((x3 - x2) * (-1))) /. (float_of_int (y3 - y2));
    	mx1 := (float_of_int (x1 + x2)) /. 2.0;
      mx2 := (float_of_int (x2 + x3)) /. 2.0;
      my1 := (float_of_int (y1 + y2)) /. 2.0;
      my2 := (float_of_int (y2 + y3)) /. 2.0;

      (* 07/05/2003 - 8h50 *)
      if (!m1 -. !m2) <> 0.0 then begin
      	xC := (!m1 *. !mx1 -. !m2 *. !mx2 +. !my2 -. !my1) /. (!m1 -. !m2);
        yC := !m1 *. (!xC -. !mx1) +. !my1
      end
      else begin
      	xC := float_of_int ((x1 + x2 + x3) / 3);
        yC := float_of_int ((y1 + y2 + y3) / 3)
      end
    end; (* Fim else *)

  	dx    := (float_of_int x2) -. !xC;
    dy    := (float_of_int y2) -. !yC;
    rsqr  := !dx *. !dx +. !dy *. !dy;
    radix := (sqrt !rsqr);
    dx    := (float_of_int xp) -. !xC;
    dy    := (float_of_int yp) -. !yC;
    drsqr := !dx *. !dx +. !dy *. !dy;

    if !drsqr <= !rsqr then
    	true
    else
    	false
    end;;
(*val inCircle : int -> int -> int -> int -> int -> int -> int -> int -> bool =
  <fun>
*)


(*
	Determines which side of a line the point (xp,yp) lies.
	The line goes from (x1,y1) to (x2,y2)
	Returns -1 for a point to the left
	         0 for a point on the line
	        +1 for a point to the right
*)
let whichSide xp yp x1 y1 x2 y2 =
	let equation = ref 0 in
  equation := ((yp - y1) * (x2 - x1)) - ((y2 - y1) * (xp - x1));

  if !equation > 0 then
  	(-1)
  else if !equation = 0 then
  	0
  else
  	1;;
(*val whichSide : int -> int -> int -> int -> int -> int -> int = <fun>*)


(*
	Takes as input NVERT vertices in arrays Vertex()
	Returned is a list of NTRI triangular faces in the array
	Triangle(). These triangles are arranged in clockwise order.
*)
let triangulate nvert =
	(* For Super Triangle *)
	let xmin = ref 0
  and xmax = ref 0
  and ymin = ref 0
  and ymax = ref 0
  and xmid = ref 0
  and ymid = ref 0
  and dx   = ref 0
  and dy   = ref 0
  and dmax = ref 0

  (* General Variables *)
  and i    = ref (-1)
  and j		= ref (-1)
  and k		= ref 0
  and ntri	= ref 0
  and inc	= ref false in

  (*
  	Find the maximum and minimum vertex bounds.
		This is to allow calculation of the bounding triangle
 	*)
  xmin := vertex.(0).x;
  ymin := vertex.(0).y;
  xmax := !xmin;
  ymax := !ymin;

  for i=1 to nvert do
  	if vertex.(i).x < !xmin then
    	xmin := vertex.(i).x;
    if vertex.(i).x > !xmax then
    	xmax := vertex.(i).x;
    if vertex.(i).y < !ymin then
    	ymin := vertex.(i).y;
    if vertex.(i).y > !ymax then
    	ymax := vertex.(i).y
  done;	(* Fim for i *)

  dx := (!xmax - !xmin);
  dy := (!ymax - !ymin);

  if !dx > !dy then
  	dmax := !dx
  else
  	dmax := !dy;

  xmid := (!xmax + !xmin) / 2;
  ymid := (!ymax + !ymin) / 2;

  (*
  	Set up the supertriangle
		This is a triangle which encompasses all the sample points.
		The supertriangle coordinates are added to the end of the
		vertex list. The supertriangle is the first triangle in
		the triangle list.
  *)
  vertex.(nvert+1) <- {x=(!xmid - 2 * !dmax); y=(!ymid - !dmax)};
  vertex.(nvert+2) <- {x=(!xmid); y=(!ymid + 2 * !dmax)};
  vertex.(nvert+3) <- {x=(!xmid + 2 * !dmax); y=(!ymid - !dmax)};

  triangle.(0) <- {vv0=(nvert + 1); vv1=(nvert + 2); vv2=(nvert + 3)};
  complete.(0) <- false;
  ntri := 0;

  (* Include each point one at a time into the existing mesh *)
  for i=0 to nvert do
  	nedge := (-1);

    (*
    	Set up the edge buffer.
    	If the point (Vertex(i).x,Vertex(i).y) lies inside the circumcircle then the
    	three edges of that triangle are added to the edge buffer.
    *)
    j := (-1);
    while !j < !ntri do
    	j := !j + 1;
      if complete.(!j) <> true then begin
      inc := (inCircle vertex.(i).x vertex.(i).y
      								 vertex.(triangle.(!j).vv0).x vertex.(triangle.(!j).vv0).y
                       vertex.(triangle.(!j).vv1).x vertex.(triangle.(!j).vv1).y
                       vertex.(triangle.(!j).vv2).x vertex.(triangle.(!j).vv2).y);

      (* 30/04/2003 - 20h04 *)
      (* Include this if points are sorted by X *)
      (* 18/05/2003 - 23h05 *)
      if (!xC +. !radix) < (float_of_int vertex.(i).x) then
      	complete.(!j) <- true
      else if !inc = true then begin
      	edges.(0).(!nedge + 1) <- triangle.(!j).vv0;
        edges.(1).(!nedge + 1) <- triangle.(!j).vv1;
        edges.(0).(!nedge + 2) <- triangle.(!j).vv1;
        edges.(1).(!nedge + 2) <- triangle.(!j).vv2;
        edges.(0).(!nedge + 3) <- triangle.(!j).vv2;
        edges.(1).(!nedge + 3) <- triangle.(!j).vv0;

        nedge := !nedge + 3;
        triangle.(!j) <- {vv0=triangle.(!ntri).vv0; vv1=triangle.(!ntri).vv1; vv2=triangle.(!ntri).vv2};
        complete.(!j) <- complete.(!ntri);

        j := !j - 1;
        ntri := !ntri - 1
      end;  (* Fim if *)
    end  (* Fim if *)
  done;	(* Fim while *)

  (*
  	Tag multiple edges
		Note: if all triangles are specified anticlockwise then all
		interior edges are opposite pointing in direction.
  *)
  for j=0 to !nedge-1 do
  	if not (edges.(0).(j) = (-1)) && not (edges.(1).(j) = (-1)) then begin
    	for k=j+1 to !nedge do
      	if not (edges.(0).(k) = (-1)) && not (edges.(1).(k) = (-1)) then begin
        	if edges.(0).(j) = edges.(1).(k) then begin
          	if edges.(1).(j) = edges.(0).(k) then begin
            	edges.(0).(j) <- (-1);
              edges.(1).(j) <- (-1);
              edges.(0).(k) <- (-1);
              edges.(1).(k) <- (-1)
            end  (* Fim if *)
          end  (* Fim if *)
        end  (* Fim i *)
      done	(* Fim for k *)
    end  (* Fim if *)
  done; (* Fim for j *)

  (*
  	Form new triangles for the current point
		Skipping over any tagged edges.
		All edges are arranged in clockwise order.
  *)
  for j=0 to !nedge do
  	if not (edges.(0).(j) = (-1)) && not (edges.(1).(j) = (-1)) then  begin
    	ntri := !ntri + 1;
      triangle.(!ntri) <- {vv0=edges.(0).(j); vv1=edges.(1).(j); vv2=i};
      complete.(!ntri) <- false;
    end  (* Fim if *)
  done;	(* Fim for j *)
done;	(* Fim for i *)

(*
	Remove triangles with supertriangle vertices
  These are triangles which have a vertex number greater than NVERT
 *)
i := (-1);
while !i < !ntri do
	i := !i + 1;
  if triangle.(!i).vv0 > nvert || triangle.(!i).vv1 > nvert ||
  	triangle.(!i).vv2 > nvert then begin
    triangle.(!i) <- {vv0=triangle.(!ntri).vv0; vv1=triangle.(!ntri).vv1; vv2=triangle.(!ntri).vv2};

    i := !i - 1;
    (* 30/04/2003 - 18h59 *)
    ntri := !ntri - 1
  end  (* Fim if *)
done;	(* Fim while i *)
!ntri;;
(*val triangulate : int -> int = <fun>*)


(* Control definitions *)
exception End;;

(* Definicao do tipo evento *)
type event = Button_down | Button_up | Key_pressed | Mouse_motion | Poll;;

type status = {
	mouse_x : int;
  mouse_y : int;
  button  : bool;
  keypressed : bool;
  key : char
};;

type state = {maxx:int; maxy:int; mutable cx:int; mutable cy:int;
              scale:int; bc:Graphics.color; fc:Graphics.color;
              pc:Graphics.color};;


(*  *)
let draw_rect x0 y0 w h =       (* X0, Y0, Largura, Altura *)
	let x1=x0+w and y1=y0+h in    (* Definicao do segundo par de coordenadas *)
  Graphics.set_color 1945;      (* Definicao de cor do tracado *)
  Graphics.moveto x0 y0;        (* Movimento da caneta para a (X0, Y0) *)
  Graphics.lineto x0 y1;
  Graphics.lineto x1 y1;
  Graphics.lineto x1 y0;
  Graphics.lineto x0 y0;;
(*val draw_rect : int -> int -> int -> int -> unit = <fun>*)


(* *)
let skel f_init f_end f_key f_mouse f_coord f_except =
	f_init ();
  try
  	while true do
    	try
      	let s = Graphics.wait_next_event [Graphics.Button_down;
        																	Graphics.Key_pressed;
                                          Graphics.Mouse_motion] in
        if s.Graphics.keypressed then
        	f_key s.Graphics.key
        else if s.Graphics.button then
        	f_mouse s.Graphics.mouse_x s.Graphics.mouse_y
        else
        	f_coord s.Graphics.mouse_x s.Graphics.mouse_y
      with
      		End -> raise End
      	| e   -> f_except e
    done
  with
  	End -> f_end ();;
(*val skel :
  (unit -> 'a) -> (unit -> unit) -> (char -> 'b) ->
  (int -> int -> 'b) -> (int -> int -> 'b) -> (exn -> 'b) -> unit = <fun>
*)


(* *)
let t_end s () =
	Graphics.close_graph();
  print_string "Good bye...";
  print_newline();;
(*val t_end : 'a -> unit -> unit = <fun>*)


(* *)
let t_coord s x y =
	if (x-40) >= 0 && (x-40) <= 500 && (y-20) >=0  && (y-20) <= 350 then begin
  	Graphics.set_color (Graphics.rgb 130 130 130);
    Graphics.fill_rect 0 0 120 20;

    Graphics.set_color Graphics.black;
    Graphics.moveto 5 5;
    let sxy = "(x=" ^ (string_of_int (x-40)) ^ ",y=" ^ (string_of_int (y-20)) ^ ") " in
    Graphics.draw_string sxy
	end;;
(*val t_coord : 'a -> int -> int -> unit = <fun>*)


(* *)
let t_except s ex = ();;


(* *)
let t_key s c =
	(* 17/03/2003 - 20h32 *)
  if c != '\n' then
  	raise End
  else
  	();;
(*val t_key : 'a -> char -> unit = <fun>*)

let stel = {maxx=550; maxy=450; cx=10; cy=10;
            scale=1; bc=Graphics.rgb 130 130 130;
            fc=Graphics.black; pc=Graphics.red};;

(* *)
let t_init s () =
	Graphics.open_graph (" " ^ (string_of_int (s.scale*s.maxx)) ^
  "x" ^ (string_of_int (s.scale*s.maxy)));

  (* Establecimento do titulo da janela *)
   Graphics.set_window_title ("Triangulate in OCaml - Andr� Luiz Moura");

   Graphics.set_color s.bc;
   Graphics.fill_rect 0 0 (s.scale*s.maxx+1) (s.scale*s.maxy+1);

   Graphics.set_color Graphics.white;
   Graphics.moveto 40 395;
   Graphics.draw_string "Press any valid key to exit or";

   Graphics.moveto 40 380;
   Graphics.draw_string "click on white panel to insert point.";

   Graphics.fill_rect 40 20 (s.scale*s.maxx-45) (s.scale*s.maxy-100);;
(*val t_init : state -> unit -> unit = <fun>*)


(* *)
let t_mouse s x y =
	if (x-40) > 1 && (x-40) < 499 && (y-20) > 1 && (y-20) < 349 then begin
  	(* 05/04/2003 - 20h59 *)
    vertex.(!tPoints-1) <- {x=(x-40); y=(y-20)};

    if !tPoints > 2 then begin
    	(* 18/05/2003 - 19h20 *)
    	ignore (quicksort vertex 0 (!tPoints-1));

      (* 15/05/2003 - 9h30 *)
      (* Initial time *)
      tInic := Sys.time ();

      (* Returns number of triangles created *)
      howMany := triangulate (!tPoints-1);

      (* 15/05/2003 - 9h31 *)
      (* Terminal time *)
      tFin := Sys.time ()
    end
    else
      draw_rect (x-1) (y-1) 2 2;

    tPoints := !tPoints + 1;

    Graphics.set_color (Graphics.rgb 130 130 130);
    Graphics.fill_rect 120 0 430 20;

    Graphics.set_color Graphics.black;
    Graphics.moveto 120 5;

    (* 06/05/2003 - 20h31 *)
    let sptt = "Points:" ^ (string_of_int (!tPoints-1)) ^  "   Triangles:" ^ (string_of_int (!howMany+1))
                ^ "   Time:" ^ (string_of_float (!tFin -. !tInic)) ^ " s" in
    	Graphics.draw_string sptt;

    (* Draw the created triangles *)
    if !howMany > (-1) then begin
      (* 06/05/2003 - 18h39 *)
      apague_painel 40 20 (s.scale*s.maxx-45) (s.scale*s.maxy-100) (Graphics.white);

      Graphics.set_color Graphics.red;

      for i=0 to !howMany do
      	(* 07/05/2003 - 22h55 *)
        Graphics.moveto (vertex.(triangle.(i).vv0).x+40) (vertex.(triangle.(i).vv0).y+20);

        Graphics.lineto (vertex.(triangle.(i).vv0).x+40) (vertex.(triangle.(i).vv0).y+20);
        Graphics.lineto (vertex.(triangle.(i).vv1).x+40) (vertex.(triangle.(i).vv1).y+20);

        Graphics.lineto (vertex.(triangle.(i).vv1).x+40) (vertex.(triangle.(i).vv1).y+20);
        Graphics.lineto (vertex.(triangle.(i).vv2).x+40) (vertex.(triangle.(i).vv2).y+20);

        Graphics.lineto (vertex.(triangle.(i).vv0).x+40) (vertex.(triangle.(i).vv0).y+20);
        Graphics.lineto (vertex.(triangle.(i).vv2).x+40) (vertex.(triangle.(i).vv2).y+20)
      done
    end
  end;;
(*val t_mouse : state -> int -> int -> unit = <fun>*)


(* *)
let slate () =
	skel (t_init stel) (t_end stel) (t_key stel)
  		 (t_mouse stel) (t_coord stel) (t_except stel);;
(*val slate : unit -> unit = <fun>*)

slate ();;
