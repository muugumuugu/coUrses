Option Strict On
Option Explicit On

Imports System.Math

Namespace Delaunay

  ''' <summary>
  ''' Code for utilizing the Delaunay Triangulation method for surface modeling.
  ''' </summary>
  ''' <remarks>
  ''' Credit to Paul Bourke (pbourke@swin.edu.au) for the original Fortran 77 Program.
  ''' Converted from the VB-Conversion by EluZioN (EluZioN@casesladder.com).
  ''' Modified in VB.NET 2.0 by edhubbell@gmail.com to something that almost looks like OOP.
  ''' Check out: http://astronomy.swin.edu.au/~pbourke/terrain/triangulate/
  ''' You can use this code however you like providing the above credits remain intact.
  ''' The error reporting in this namespace is pretty lousy - Feel free to improve it. 
  ''' </remarks>
  Friend Class DelaunayTriangulation

    ''' <summary>
    ''' The maximum number of triangles that can be created.
    ''' </summary>
    Private Const MaxTriangles As Short = 1000

    ''' <summary>
    ''' A Triangle is defined by 3 vertex points from the oVertices collection.
    ''' </summary>
    ''' <remarks>
    ''' For example, if vv0 = 12, then one of the 3 points that defines this 
    ''' triangle is the (x,y,z) coordinate stored in the vertex collection oVertex(12)
    ''' </remarks>
    Friend Structure Triangle
      Public vv0 As Integer
      Public vv1 As Integer
      Public vv2 As Integer
    End Structure

    ''' <summary>
    ''' Array of all the triangles that are used to model the surface.
    ''' </summary>
    ''' <remarks>
    ''' While .NET arrays are all 0-based, the 0 element of this array is never used.  
    ''' This is a good thing to know.  I tried for a long time to modify the code so that
    ''' it could use a 0-based array here, but I gave up a long time ago.  This class works, 
    ''' so just implement it and save yourself a lot of grief.
    ''' </remarks>
    Public oTriangles(MaxTriangles) As Triangle

    ''' <summary>
    ''' Collection of all the vertices that are used to create the triangles in oTriangles.
    ''' </summary>
    ''' <remarks></remarks>
    Public oVertices As Vertices

    ''' <summary>
    ''' Stores the count of all triangles.
    ''' </summary>
    ''' <remarks></remarks>
    Private miTriangleCount As Integer

    ''' <summary>
    ''' Stores the count of all vertices (excluding the vertices for the SuperTriangle).
    ''' </summary>
    ''' <remarks></remarks>
    Private miVertexCount As Integer

    Public Sub New()
      oVertices = New Vertices
    End Sub

    ''' <summary>
    ''' Returns TRUE if the vertex lies inside the circumcircle
    ''' made up by points of the triangle.
    ''' </summary>
    ''' <param name="theVertex">The vertex to be evaluated.</param>
    ''' <param name="theTriangle">The triangle to be evaluated.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function InCircle(ByRef theVertex As Vertex, ByRef theTriangle As Triangle) As Boolean
      'The circumcircle centre is (xc,yc) and the radius r
      Dim eps As Double
      Dim m1, m2 As Double
      Dim mx0, mx1, my0, my1 As Double
      Dim dx, dy As Double
      Dim xc, yc, r As Double
      Dim rsqr As Double
      Dim drsqr As Double

      Dim xp, x0, x1, x2 As Integer
      Dim yp, y0, y1, y2 As Integer

      xp = theVertex.x
      yp = theVertex.y
      x0 = oVertices.Item(theTriangle.vv0).x
      y0 = oVertices.Item(theTriangle.vv0).y
      x1 = oVertices.Item(theTriangle.vv1).x
      y1 = oVertices.Item(theTriangle.vv1).y
      x2 = oVertices.Item(theTriangle.vv2).x
      y2 = oVertices.Item(theTriangle.vv2).y

      eps = 0.000001

      InCircle = False

      If Abs(y0 - y1) < eps And Abs(y1 - y2) < eps Then
        MsgBox("INCIRCUM - F - Points are coincident !!")
        Exit Function
      End If

      If Abs(y1 - y0) < eps Then
        m2 = -(x2 - x1) / (y2 - y1)
        mx1 = (x1 + x2) / 2
        my1 = (y1 + y2) / 2
        xc = (x1 + x0) / 2
        yc = m2 * (xc - mx1) + my1
      ElseIf Abs(y2 - y1) < eps Then
        m1 = -(x1 - x0) / (y1 - y0)
        mx0 = (x0 + x1) / 2
        my0 = (y0 + y1) / 2
        xc = (x2 + x1) / 2
        yc = m1 * (xc - mx0) + my0
      Else
        m1 = -(x1 - x0) / (y1 - y0)
        m2 = -(x2 - x1) / (y2 - y1)
        mx0 = (x0 + x1) / 2
        mx1 = (x1 + x2) / 2
        my0 = (y0 + y1) / 2
        my1 = (y1 + y2) / 2
        xc = (m1 * mx0 - m2 * mx1 + my1 - my0) / (m1 - m2)
        yc = m1 * (xc - mx0) + my0
      End If

      dx = x1 - xc
      dy = y1 - yc
      rsqr = dx * dx + dy * dy
      r = Sqrt(rsqr)
      dx = xp - xc
      dy = yp - yc
      drsqr = dx * dx + dy * dy

      If drsqr <= rsqr Then InCircle = True

    End Function

    ''' <summary>
    ''' Fills the oTriangles object with the proper Delaunay triangles 
    ''' used to model a surface defined by the set of points in oVerticies.
    ''' </summary>
    ''' <remarks>The triangles are arranged in clockwise order.</remarks>
    Public Sub Triangulate()
      Dim Edges(2, MaxTriangles * 3) As Integer
      Dim Nedge As Integer

      'General Variables
      Dim i As Integer
      Dim j As Integer
      Dim k As Integer
      Dim ntri As Integer
      Dim inc As Boolean

      Dim aVertex As Vertex

      miVertexCount = oVertices.Count

      'Set up the supertriangle
      'This is a triangle which encompasses all the sample points.
      'The supertriangle coordinates are added to the end of the
      'vertex list. 
      aVertex = New Vertex(CInt(oVertices.MidX - 2 * oVertices.DeltaMax), CInt(oVertices.MidY - oVertices.DeltaMax))
      oVertices.Add(aVertex, True)
      aVertex = New Vertex(CInt(oVertices.MidX), CInt(oVertices.MidY + 2 * oVertices.DeltaMax))
      oVertices.Add(aVertex, True)
      aVertex = New Vertex(CInt(oVertices.MidX + 2 * oVertices.DeltaMax), CInt(oVertices.MidY - oVertices.DeltaMax))
      oVertices.Add(aVertex, True)

      oTriangles(1).vv0 = oVertices.Count - 3
      oTriangles(1).vv1 = oVertices.Count - 2
      oTriangles(1).vv2 = oVertices.Count - 1
      ntri = 1

      'Include each point one at a time into the existing mesh
      ' but don't include the super triangle verticies
      For i = 0 To oVertices.Count - 3
        Nedge = 0
        'Set up the edge buffer.
        'If the point (Vertices(i).x,Vertices(i).y) lies inside the circumcircle then the
        'three edges of that triangle are added to the edge buffer.
        j = 0
        Do
          j = j + 1
          inc = InCircle(oVertices.Item(i), oTriangles(j))

          If inc Then
            Edges(1, Nedge + 1) = oTriangles(j).vv0
            Edges(2, Nedge + 1) = oTriangles(j).vv1
            Edges(1, Nedge + 2) = oTriangles(j).vv1
            Edges(2, Nedge + 2) = oTriangles(j).vv2
            Edges(1, Nedge + 3) = oTriangles(j).vv2
            Edges(2, Nedge + 3) = oTriangles(j).vv0
            Nedge = Nedge + 3
            oTriangles(j).vv0 = oTriangles(ntri).vv0
            oTriangles(j).vv1 = oTriangles(ntri).vv1
            oTriangles(j).vv2 = oTriangles(ntri).vv2
            j = j - 1
            ntri = ntri - 1
          End If
        Loop While j < ntri

        'Tag multiple edges
        'Note: if all triangles are specified anticlockwise then all
        'interior edges are opposite pointing in direction.
        For j = 1 To Nedge - 1
          If Edges(1, j) <> -1 And Edges(2, j) <> -1 Then
            For k = j + 1 To Nedge
              If Edges(1, k) <> -1 And Edges(2, k) <> -1 Then
                If Edges(1, j) = Edges(2, k) Then
                  If Edges(2, j) = Edges(1, k) Then
                    Edges(1, j) = -1
                    Edges(2, j) = -1
                    Edges(1, k) = -1
                    Edges(2, k) = -1
                  End If
                End If
              End If
            Next k
          End If
        Next j

        'Form new triangles for the current point
        'Skipping over any tagged edges.
        'All edges are arranged in clockwise order.
        For j = 1 To Nedge
          If Edges(1, j) <> -1 And Edges(2, j) <> -1 Then
            ntri = ntri + 1
            oTriangles(ntri).vv0 = Edges(1, j)
            oTriangles(ntri).vv1 = Edges(2, j)
            oTriangles(ntri).vv2 = i
          End If
        Next j
      Next i

      'Remove triangles with supertriangle vertices
      'These are triangles which have a vertex number greater than NVERT
      i = 0
      Do
        i = i + 1
        If oTriangles(i).vv0 > iVertexCount - 1 Or oTriangles(i).vv1 > iVertexCount - 1 Or oTriangles(i).vv2 > iVertexCount - 1 Then
          oTriangles(i).vv0 = oTriangles(ntri).vv0
          oTriangles(i).vv1 = oTriangles(ntri).vv1
          oTriangles(i).vv2 = oTriangles(ntri).vv2
          i = i - 1
          ntri = ntri - 1
        End If
      Loop While i < ntri

      miTriangleCount = ntri
    End Sub

    ''' <summary>
    ''' Returns the Z value (height) of a point (iX, iY) on the modeled surface.
    ''' </summary>
    ''' <param name="iX">The x coordinate of the point (iX,iY).</param>
    ''' <param name="iY">The y coordinate of the point (iX,iY).</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function ZValue(ByVal iX As Integer, ByVal iY As Integer) As Double
      Dim i As Integer

      ZValue = 0

      For i = 1 To miTriangleCount
        If InTriangle(iX, iY, oTriangles(i)) = True Then
          ZValue = PlanePoint(iX, iY, oVertices.Item(oTriangles(i).vv0), oVertices.Item(oTriangles(i).vv1), oVertices.Item(oTriangles(i).vv2))
          ZValue = CDbl(FormatNumber(ZValue, 0))
          If ZValue > 0 Then
            Exit Function
          End If
        End If
      Next

    End Function

    ''' <summary>
    ''' Checks to see which triangle the point (iX,iY) is contained within.
    ''' </summary>
    ''' <param name="iX">The x coordinate of the point (iX,iY).</param>
    ''' <param name="iY">The y coordinate of the point (iX,iY).</param>
    ''' <returns>The index of the bounding triangle.</returns>
    ''' <remarks></remarks>
    Public Function BoundingTriangle(ByVal iX As Integer, ByVal iY As Integer) As Integer
      Dim i As Integer

      BoundingTriangle = 0

      For i = miTriangleCount To 1 Step -1
        If InTriangle(iX, iY, oTriangles(i)) = True Then
          BoundingTriangle = i
          Exit Function
        End If
      Next

    End Function

    ''' <summary>
    ''' Determines which side of a line the point (iX,iY) lies.  
    ''' Returns -1 for a point to the left, +1 for a point to the right, 
    ''' and 0 for a point on the line.
    ''' </summary>
    ''' <param name="iX">The x coordinate of point (iX,iY).</param>
    ''' <param name="iY">The y coordinate of point (iX,iY).</param>
    ''' <param name="vertex1">One endpoint of the line to be evaluated.</param>
    ''' <param name="vertex2">The other endpoint of the line to be evaluated.</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WhichSide(ByVal iX As Integer, ByVal iY As Integer, ByVal vertex1 As Vertex, ByVal vertex2 As Vertex) As Integer
      Dim equation As Long

      equation = ((iY - vertex1.y) * (vertex2.x - vertex1.x))
      equation = equation - ((vertex2.y - vertex1.y) * (iX - vertex1.x))

      If equation > 0 Then
        WhichSide = -1
      ElseIf equation = 0 Then
        WhichSide = 0
      Else
        WhichSide = 1
      End If

    End Function

    ''' <summary>
    ''' Returns TRUE if the point (iX,iY) lies inside theTriangle.
    ''' </summary>
    ''' <param name="iX">The x coordinate of point (iX,iY).</param>
    ''' <param name="iY">The y coordinate of point (iX,iY).</param>
    ''' <param name="theTriangle"></param>
    ''' <returns></returns>
    ''' <remarks>
    ''' A point is in the triangle if it is on the same side of all the edges
    ''' or if it lies on one of the edges.
    ''' </remarks>
    Private Function InTriangle(ByVal iX As Integer, ByVal iY As Integer, ByVal theTriangle As Triangle) As Boolean
      Dim side1, side2, side3 As Integer
      Dim p1, p2, p3 As Vertex

      p1 = oVertices.Item(theTriangle.vv0)
      p2 = oVertices.Item(theTriangle.vv1)
      p3 = oVertices.Item(theTriangle.vv2)

      side1 = WhichSide(iX, iY, p1, p2)
      side2 = WhichSide(iX, iY, p2, p3)
      side3 = WhichSide(iX, iY, p3, p1)

      InTriangle = False

      If (side1 = 0) And (side2 = 0) Then InTriangle = True
      If (side1 = 0) And (side3 = 0) Then InTriangle = True
      If (side2 = 0) And (side3 = 0) Then InTriangle = True
      If (side1 = 0) And (side2 = side3) Then InTriangle = True
      If (side2 = 0) And (side1 = side3) Then InTriangle = True
      If (side3 = 0) And (side1 = side2) Then InTriangle = True
      If (side1 = side2) And (side2 = side3) Then InTriangle = True

    End Function

    ''' <summary>
    ''' Given a plane through the point p1,p2,p3 and a point on the x-y
    ''' plane determine the intersection of the perpendicular.
    ''' </summary>
    ''' <param name="iX">The x coordinate of point (iX,iY).</param>
    ''' <param name="iY">The y coordinate of point (iX,iY).</param>
    ''' <param name="p1"></param>
    ''' <param name="p2"></param>
    ''' <param name="p3"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function PlanePoint(ByVal iX As Double, ByVal iY As Double, ByVal p1 As Vertex, ByVal p2 As Vertex, ByVal p3 As Vertex) As Double
      Const EPSILON As Double = 0.0001
      Dim a, b, c, d As Double

      a = p1.y * (p2.z - p3.z) + p2.y * (p3.z - p1.z) + p3.y * (p1.z - p2.z)
      b = p1.z * (p2.x - p3.x) + p2.z * (p3.x - p1.x) + p3.z * (p1.x - p2.x)
      c = p1.x * (p2.y - p3.y) + p2.x * (p3.y - p1.y) + p3.x * (p1.y - p2.y)
      d = -p1.x * (p2.y * p3.z - p3.y * p2.z) - p2.x * (p3.y * p1.z - p1.y * p3.z) - p3.x * (p1.y * p2.z - p2.y * p1.z)

      If (Abs(c) > EPSILON) Then
        PlanePoint = (-(a * iX + b * iY + d) / c)
      Else
        PlanePoint = (0.0)
      End If

    End Function

    ''' <summary>
    ''' Returns the count of all triangles used to model the surface. 
    ''' </summary>
    Public ReadOnly Property iTriangleCount() As Integer
      Get
        Return miTriangleCount
      End Get
    End Property

    ''' <summary>
    ''' Returns the count of all vertices (excluding the vertices for the SuperTriangle).
    ''' </summary>
    Public ReadOnly Property iVertexCount() As Integer
      Get
        Return miVertexCount
      End Get
    End Property

  End Class

  ''' <summary>
  ''' A single data point (x,y,z).
  ''' </summary>
  ''' <remarks>A collection of Vertex objects will be used to define a surface.</remarks>
  Friend Class Vertex
    Public x As Integer
    Public y As Integer
    Public z As Double

    Public Sub New()
      'do nothing
      x = 0
      y = 0
      z = 0
    End Sub

    Public Sub New(ByVal iX As Integer, ByVal iY As Integer, ByVal dZ As Double)
      x = iX
      y = iY
      z = dZ
    End Sub

    Public Sub New(ByVal iX As Integer, ByVal iY As Integer)
      x = iX
      y = iY
      z = 0
    End Sub

  End Class

  ''' <summary>
  ''' Collection of Vertex objects.  This collection represents all of the (x,y,z) points 
  ''' that are used to model the surface.
  ''' </summary>
  ''' <remarks>
  ''' The collection automatically keeps track of the MidX, MidY and DeltaMax values
  ''' that are required to define the SuperTriangle during the Triangulation operation.
  ''' </remarks>
  Friend Class Vertices
    Inherits System.Collections.CollectionBase
    Private miMaxX As Integer
    Private miMaxY As Integer
    Private miMinX As Integer
    Private miMinY As Integer
    Private msngMidX As Single
    Private msngMidY As Single
    Private miDeltaX As Integer
    Private miDeltaY As Integer
    Private miDeltaMax As Integer
    Public iTrueVertexCount As Integer = 0

    Public Sub Add(ByRef theVertex As Vertex, ByRef bSuperTriangle As Boolean)
      List.Add(theVertex)

      If Not bSuperTriangle Then
        If theVertex.x > miMaxX Then miMaxX = theVertex.x
        If theVertex.y > miMaxY Then miMaxY = theVertex.y
        If theVertex.x < miMinX Then miMinX = theVertex.x
        If theVertex.y < miMinY Then miMinY = theVertex.y

        miDeltaX = miMaxX - miMinX
        miDeltaY = miMaxY - miMinY
        If miDeltaX > miDeltaY Then
          miDeltaMax = miDeltaX
        Else
          miDeltaMax = miDeltaY
        End If
        msngMidX = CSng((miMaxX + miMinX) / 2)
        msngMidY = CSng((miMaxY + miMinY) / 2)
      End If

    End Sub

    Public Sub Remove(ByVal index As Integer)
      If index > Count - 1 Or index < 0 Then
        'System.Windows.Forms.MessageBox.Show("Index not valid!")
      Else
        List.RemoveAt(index)
      End If
    End Sub

    Public ReadOnly Property Item(ByVal index As Integer) As Vertex
      Get
        Return CType(List.Item(index), Vertex)
      End Get
    End Property

    Public Sub New()
      miMaxX = 0
      miMaxY = 0
      miMinX = 999999
      miMinY = 999999
    End Sub
    Public ReadOnly Property MidX() As Single
      Get
        Return msngMidX
      End Get
    End Property
    Public ReadOnly Property MidY() As Single
      Get
        Return msngMidY
      End Get
    End Property
    Public ReadOnly Property DeltaMax() As Integer
      Get
        Return miDeltaMax
      End Get
    End Property

  End Class

End Namespace
