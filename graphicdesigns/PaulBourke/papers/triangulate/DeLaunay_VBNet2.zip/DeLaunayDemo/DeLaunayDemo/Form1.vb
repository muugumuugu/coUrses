Option Strict On
Option Explicit On

Imports DeLaunayDemo.Delaunay

Public Class Form1

  Dim moTriangulation As DelaunayTriangulation

  Private Sub PictureBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseDown
    Dim x As Integer = e.X
    Dim y As Integer = e.Y
    Dim aVertexPoint As Vertex

    aVertexPoint = New Vertex(x, y)
    moTriangulation.oVertices.Add(aVertexPoint, False)
    DrawTriangles()

  End Sub

  Public Sub DrawTriangles()
    Dim bit As Bitmap = New Bitmap(PictureBox1.Width, PictureBox1.Height)
    Dim g As Graphics = Graphics.FromImage(bit)
    Dim myPen As Pen = New Pen(Color.Blue, 1)
    Dim i As Integer

    ' Perform Triangulation Function if there are more than 2 points
    If moTriangulation.oVertices.Count > 2 Then

      'Clear the Picture Box
      PictureBox1.Refresh()
      moTriangulation.Triangulate()

      myPen.Color = Color.Blue

      ' draw each triangle
      For i = 1 To moTriangulation.iTriangleCount
        With moTriangulation
          g.DrawLine(myPen, CInt(.oVertices.Item(.oTriangles(i).vv0).x), CInt(.oVertices.Item(.oTriangles(i).vv0).y), CInt(.oVertices.Item(.oTriangles(i).vv1).x), CInt(.oVertices.Item(.oTriangles(i).vv1).y))
          g.DrawLine(myPen, CInt(.oVertices.Item(.oTriangles(i).vv1).x), CInt(.oVertices.Item(.oTriangles(i).vv1).y), CInt(.oVertices.Item(.oTriangles(i).vv2).x), CInt(.oVertices.Item(.oTriangles(i).vv2).y))
          g.DrawLine(myPen, CInt(.oVertices.Item(.oTriangles(i).vv0).x), CInt(.oVertices.Item(.oTriangles(i).vv0).y), CInt(.oVertices.Item(.oTriangles(i).vv2).x), CInt(.oVertices.Item(.oTriangles(i).vv2).y))
        End With
      Next i

      ' remove the 3 supertriangle vertices from the moTriangulation
      With moTriangulation
        .oVertices.RemoveAt(.oVertices.Count - 1)
        .oVertices.RemoveAt(.oVertices.Count - 1)
        .oVertices.RemoveAt(.oVertices.Count - 1)
      End With

      'Display the total triangle count
      lblTriangles.Text = "Triangles: " & moTriangulation.iTriangleCount

    End If

    'Display the total point count
    lblPoints.Text = "Points: " & moTriangulation.iVertexCount

    Dim aVertex As Vertex

    ' draw all the individual points
    For Each aVertex In moTriangulation.oVertices
      g.DrawEllipse(myPen, CInt(aVertex.x) - 2, CInt(aVertex.y) - 2, 4, 4)
    Next aVertex

    PictureBox1.Image = bit

  End Sub

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    ResetTriangulation()
  End Sub

  Private Sub ResetTriangulation()
    moTriangulation = New DelaunayTriangulation
  End Sub

  Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
    ResetTriangulation()
    PictureBox1.Image = Nothing
  End Sub

  Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

  End Sub
End Class
