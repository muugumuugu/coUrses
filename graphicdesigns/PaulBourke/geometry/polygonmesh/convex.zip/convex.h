/*
	convex.h
*/

#ifndef CONVEX_INC
#define CONVEX_INC
#include <windows.h>

#define CONVEX	1
#define CONCAVE	(-1)

#ifdef CPLUSPLUS
extern "C" {
#endif
INT WINAPI Convex(POINT *p, UINT n);
#ifdef CPLUSPLUS
}
#endif
#endif
