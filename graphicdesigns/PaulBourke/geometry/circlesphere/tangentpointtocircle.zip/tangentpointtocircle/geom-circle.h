//Computational Geometry for Circles

#ifndef FORMAT_GEOM_CIRCLE_H
#define FORMAT_GEOM_CIRCLE_H

int getCircleCircleIntersections(//Circle 0 Radius
                                 double   r0,
                                 //Circle 0 Center
                                 double  px0, double  py0,
                                 //Circle 1 Radius
                                 double   r1,
                                 //Circle 1 Center
                                 double  px1, double  py1,
                                 //Intersection 0
                                 double* ix0, double* iy0,
                                 //Intersection 1
                                 double* ix1, double* iy1);

int getCircleTangentPoints(//Circle Radius and Center
                           double  cr, double  cx,  double  cy,
                           //Point to determine tangency
                           double  px,  double  py,
                           //Tangent Point 0
                           double* tx0, double* ty0,
                           //Tangent Point 1
                           double* tx1, double* ty1);

#endif