%[phi, theta] = createGeo(m,N) outputs spherical coordinates of a geodesic sphere.
% Where m is a single integer between 0 and 10N^2 + 2
%       N is the tessellation frequency
%       and values of m correspond to:
%
%                             0<= m < 12         Icosahedron vertex point
%                           12 <= m < 30N - 18   Icosahedron edge point
%                     30N - 18 <= m < 10N^2 + 2  Interior surface point
%
%
%
%
% See http://scholar.lib.vt.edu/theses/available/etd-4798-232353/ for 
% description of what is essentially happening here.


function [phi, theta] = createGeo(m, N)

	%% if m < 12 %% it's an Icosahedrom vertex

		if (m == 0)
			[phi, theta] = getPoint(0,0, 1,N); %Top Vertex
		elseif (m == 1)
			[phi, theta] = getPoint(0,0,20,N); %Bottom Vertex
		elseif (m < 12)
			[phi, theta] = getPoint(0,0, m+4, N); %Top of one of the middle verticies
		elseif (m < 30*N - 18)

			edge  = mod(m-12, 30);
			point = floor((m-12)/30);
			
			if (edge < 5)
				% top face left side
				[phi, theta] = getPoint(0,point+1,edge+1, N);	
				return;			
		
			elseif (edge < 10)
				% top face bottom
				[phi,theta] = getPoint(point+1, N-(point+1), edge-4, N);
				return;

			elseif (edge < 15)
				%middle left side 
				[phi, theta] = getPoint(0, point+1, edge - 4, N); 
				return;

			elseif (edge < 20)
				%middle right side
				[phi, theta] = getPoint(point+1, 0, edge - 9, N); 
				return;

			elseif (edge < 25)
				%bottom bottom
				[phi, theta] = getPoint(point+1, N-(point+1), edge-4, N);
				return;
			else
				%bottom left
				[phi, theta] = getPoint(0, point+1, edge-9, N);
				return;
			end;
		else
			
			face = mod((m-(30*N)+18),20);
			point = floor((m-(30*N)+18)/20)+1;

			offset = N-2;

			for z = 1 : N
				if point <= offset
					break;
				else
					offset = offset + N-(z+2);
				end;
			end;	

				y = offset - point + 1;
				x = N - y - z;

			[phi, theta] = 	 getPoint(x,y, face + 1, N);
			return;
		end;

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	function [phi,theta] = getPoint(x,y,face, N)


	if (face == 1)
		[phi, theta] = topFace(x,y,N);
		return;
	elseif (face <= 5)
		[p,t] = topFace(x,y,N);
		[phi, theta] = rotate(p, t, face - 1);
		return;
	elseif (face <= 10)
		[p,t] = topFace(x,y,N);
		[phi,theta] = shiftDown(p, t, face - 5);
		return;
	elseif (face <= 15)
		[p,t] = topFace(x,y,N);
		[p,t] = shiftDown(p, t, face - 10);
		[phi,theta] = flip(p,t);
		return;
	else
		[p,t] = topFace(x,y,N);
		[p,t] = rotate(p,t,face-16);
		[phi,theta] = flip(p,t);
		return;
	end;

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	function [p,t] = topFace(x,y, N)
		GOLDEN_MEAN = (1+sqrt(5))/2;
		z = N - x - y;
		x1 = x*sin(2*pi/5);
		y1 = y + x*cos(2*pi/5);
		z1 = .5*N + (N - x - y)/GOLDEN_MEAN;

		p = atan2(x1,y1);
		t  = atan2(sqrt(x1^2 + y1^2),z1);

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	function [p, t] = rotate(phi,theta, number)

		p = phi + number*2*pi/5;
		t = theta;	

	return

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

	function [p, t] = shiftDown(phi, theta, number)

		[phi, theta] = rotate(phi, theta, number-1);

		phi0 = 	pi/5 + 2*(number-1)*pi/5;

		r1 = [1/sqrt(5),  0 , 2/sqrt(5);
		      0           1 ,     0    ;
		      -2/sqrt(5), 0 , 1/sqrt(5)];


		r2 = [sin(theta)*cos(phi-phi0);
		      sin(theta)*sin(phi-phi0);
		      cos(theta)];

		xyz = r1*r2;			
					
		p = phi0 + pi/5+ atan2(xyz(2),xyz(1));
		t = atan2(sqrt(xyz(1)^2 + xyz(2)^2),xyz(3));

	return

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	

	function [p, t] = flip(phi, theta)
		p = phi + pi/5;
		t = pi - theta;

	return

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

