/*
 * RTGeodesic.java
 * Created on 4 July 2006, 14:01
 * -----------------------------
 * 
 * Allows the generation of vertex points on a geodesic sphere for a given tesselation frequency (N) 
 * for use in TdRT
 *
 * [--------------------]
 * [   Public methods   ]
 * [--------------------]------------------------------------------------------------------------------
 * [    getPointList():      returns an array of Point3d with cartesian coordinates of vertex points
 * [                         of unit  geodesic sphere with tesselation frequency N.
 * [
 * [    getNumberOfPoints(): returns number of vertex points in geodesic sphere with tesselation
 * [                         frequency N. Number of vertex points = (10*N^2 + 2)
 * [---------------------------------------------------------------------------------------------------
 *
 * 
 */

import javax.vecmath.*;
import java.lang.Math;

/**
 *
 * @author Max Downey
 */

public class RTGeodesic {
    
    private int N; //Tesselation frequency
    private int vertNum; // Number of vertices
    /** Creates a new instance of RTGeodesic */
    public RTGeodesic(int tesselationFrequency)
    {
        N = tesselationFrequency;
        vertNum = 10*N*N + 2;
    }
     
    public Point3d[] getPointList()
    {
                Point3d[] pointList = new Point3d[vertNum];
                
                for (int i = 0; i < vertNum; i++)
                {
                    pointList[i] = createGeo(i);                   
                }
                return pointList;
    }
    
    public int getNumberOfPoints()
    {
        return vertNum;
    }
    


    // x mod y
     private double mod(double x, double y)
     {
         return (y == 0) ? x : (x - (double)Math.floor(x/y)*y);                 
     }
     
/* createGeo(m,N) outputs spherical coordinates of a geodesic sphere.
 * Where m is a single integer between 0 and 10N^2 + 2
 *        and values of m correspond to:
 *
 *                             0<= m < 12         Icosahedron vertex point
 *                           12 <= m < 30N - 18   Icosahedron edge point
 *                     30N - 18 <= m < 10N^2 + 2  Interior surface point
 */ 
    
     private Point3d createGeo(int m)
     {         
        SphericalCoordinates sc;
        
        if (m == 0)
        {
            sc = getPoint(0,0,1); //Top Vertex
        }
        else if (m == 1)
        {
            sc = getPoint(0,0,20); //Bottom Vertex;
        }
        else if (m < 12)
        {
            sc = getPoint(0,0,m+4); //Top of one of the middle vertices
        }
        else if (m < 30*N -18) //Icosahedron edges
        {
            int edge  = (int)mod(m-12, 30); 
            int point = (int)Math.floor((m-12)/30);
            
            if (edge < 5)
            {
                sc = getPoint(0, point + 1, edge + 1);
            }
            else if (edge < 10)
            {
                sc = getPoint(point + 1, N-(point + 1), edge - 4);
            }
            else if (edge < 15)
            {
                sc = getPoint(0, point+1, edge - 4);
            }
            else if (edge < 20)
            {
                sc = getPoint(point + 1, 0, edge - 9);
            }
            else if (edge < 25)
            {
                sc = getPoint(point + 1, N-(point + 1), edge - 4);
            }
            else
            {
                sc = getPoint(0, point + 1, edge - 9);
            }
        }
        else    //Inner vertices
        {
            int face = (int)mod((m-(30*N)+18), 20);
            int point = (int)Math.floor((m-(30*N)+18)/20)+1;
            int offset = N - 2;
            int z;
            for (z = 1; z <=N; z++)
            {
                if (point <= offset)
                {
                    break;
                }
                else
                {
                    offset = offset + N - (z + 2);
                }
            }
            
            int y = offset - point + 1;
            int x = N - y - z;
            sc = getPoint(x,y,face + 1);
        }        
        return sc.getCartesian();
    }
            
     
     public SphericalCoordinates getPoint(int x, int y, int face)
     {
        SphericalCoordinates sc = topFace(x,y);
     
        if (face == 1)
        {            }
        else if (face <= 5)
        {
             rotate(sc, face-1);
        }
        else if (face <= 10)
        {
             shiftDown(sc, face - 5);
        }
        else if (face <= 15)
        {
             shiftDown(sc, face - 10);
             flip(sc);
        }
        else
        {
             rotate(sc, face - 16);
             flip(sc);
        }         
         return sc;        
     }          
     
     private SphericalCoordinates topFace(int x, int y)
     {
         int z = N - x - y;
         double x1 = x*Math.sin(2*Math.PI/5);
         double y1 = y + x*Math.cos(2*Math.PI/5);
         double z1 = .5*N + (N - x - y)/((1 + Math.sqrt(5))/2);
         double phi = Math.atan2(x1, y1);
         double theta = Math.atan2(Math.sqrt(Math.pow(x1,2) + Math.pow(y1,2)), z1);
         SphericalCoordinates sc = new SphericalCoordinates(theta, phi);
         return sc;
     }
     
     private void rotate(SphericalCoordinates sc, int number)
     {
         sc.phi = sc.phi + number*2*Math.PI/5;         
     }
     
     private void shiftDown(SphericalCoordinates sc, int number)
     {
         rotate(sc, number - 1);
         double phi0 = Math.PI/5 + 2*(number - 1)*Math.PI/5;
         Point3d p3d = new Point3d();
         double r1 = Math.sin(sc.theta)*Math.cos(sc.phi - phi0);
         double r3 = Math.cos(sc.theta);
         double sqrt5 = Math.sqrt(5);
         
         p3d.x = r1/sqrt5 + 2*r3/sqrt5;
         p3d.y = Math.sin(sc.theta)*Math.sin(sc.phi - phi0);
         p3d.z = r3/sqrt5 - 2*r1/sqrt5;
         
         sc.phi = phi0 + Math.PI/5 + Math.atan2(p3d.y, p3d.x);
         sc.theta = Math.atan2(Math.sqrt(p3d.x*p3d.x + p3d.y*p3d.y), p3d.z);
     } 
     
     private void flip(SphericalCoordinates sc)
     {
         sc.phi = sc.phi + Math.PI/5;
         sc.theta = Math.PI - sc.theta;         
     }    
}

