%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This method works by dividing a unit sphere into N equally spaced 
% horizontal planes, forming N circles (with the circles at the poles 
% actually being points). Each horizontal plane contains exactly one 
% point. The kth point can be found by travelling upwards along a great 
% circle from the k-1th point to the next horizontal plane and then 
% travelling a certain distance anticlockwise around the azimuth. 
% Placing points in this manner will cause them to spiral upwards 
% around the surface of the sphere. Numerical analysis conducted 
% by E.B. Saff concludes that the distance travelled around 
% the azimuth should be close to 3.6/sqrt(N). 
%
% Given that a point is placed on each horizontal plane and that
% there are N horizontal planes it is easy to see that for this method, 
% the number of points can be arbitrarily chosen.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


N = 1000  % Number of points
	

	for k = 1 : N
		h = -1 + 2*(k-1)/(N-1);
		theta(k) = acos(h); 	

		if (k == 1) | (k == N)
			phi(k) = 0;
		else
			phi(k) = mod((phi(k-1) + 3.6/sqrt(N*(1-h^2))),  (2*pi));
		end
	
		scatter3(cos(phi(k))*sin(theta(k)), sin(phi(k))*sin(theta(k)), cos(theta(k)));	

	end
%EOF