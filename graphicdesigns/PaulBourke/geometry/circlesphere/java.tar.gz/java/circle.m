%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This method, explained in [Rusin 1995] involves dividing a unit 
% sphere into N+1 horizontal planes and placing points on the 
% circles that these planes trace out at equally spaced distances. 
% Placing points in this manner results in fewer points around the 
% circles created by planes close to the poles than those created 
% towards the middle of the sphere (and thus doesn�t suffer from 
% point bunching as the constant angular separation method does). 
% This method, like the geodesic method doesn�t allow for an arbitrary 
% number of points. 
%
%
%[Rusin 1995] Dave Rusin, �Equally spaced points on a Sphere�, 
% http://www.math.niu.edu/~rusin/known-math/95/equispace.elect
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = 60
point = 1;

deltaPhi = pi/(N-1);
dia = sqrt(2 - 2*cos(deltaPhi));
horz_stagger = 0;

for circle = 0 : N-1
	phi = circle*deltaPhi;
	rad = sin(phi);

	if (2*rad^2 == 0)
		num_balls = 1;
	elseif acos((2*rad^2-dia^2)/(2*rad^2)) == 0
		num_balls = 1;
	else	
		num_balls = floor(2*pi / acos((2*rad^2-dia^2)/(2*rad^2)));
	end;

	theta_inc = 2*pi/num_balls;
	
	for m = 0 : num_balls - 1	
		theta = m*theta_inc + horz_stagger;

		xyz(point,:) = [rad*sin(theta), cos(phi), rad*cos(theta)];
		scatter3(xyz(point,1), xyz(point,2),xyz(point,3));

		point = point + 1;
	end;

end;